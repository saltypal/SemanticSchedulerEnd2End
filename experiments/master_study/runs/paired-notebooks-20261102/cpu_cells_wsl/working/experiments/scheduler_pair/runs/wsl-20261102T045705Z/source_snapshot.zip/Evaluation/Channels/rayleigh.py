"""Flat Rayleigh channel reserved for controlled ablations beyond Stage 1A."""

from dataclasses import dataclass

from Evaluation.Channels.channel_utils import (
    complex_to_real_per_image,
    esn0_to_noise_variance,
    normalize_complex_per_image,
    real_to_complex_per_image,
    require_torch,
)
from Evaluation.Artifacts import LatentArtifact, TransmissionArtifact
from Evaluation.Interfaces import ChannelInterface


@dataclass(slots=True)
class RayleighChannel(ChannelInterface):
    """Perfect-CSI flat Rayleigh channel; not part of the locked Stage 1A results."""

    name: str = "rayleigh_perfect_csi"

    def transmit(self, latent: LatentArtifact, snr_db: float, **options: object) -> TransmissionArtifact:
        torch = require_torch()
        clean = latent.tensor if latent.rate_mask is None else latent.tensor * latent.rate_mask
        complex_symbols, original_shape = real_to_complex_per_image(clean)
        normalized, scale = normalize_complex_per_image(complex_symbols)
        fading = torch.complex(torch.randn_like(normalized.real), torch.randn_like(normalized.imag)) / (2.0**0.5)
        standard_deviation = (esn0_to_noise_variance(snr_db) / 2.0) ** 0.5
        noise = torch.complex(
            torch.randn_like(normalized.real) * standard_deviation,
            torch.randn_like(normalized.imag) * standard_deviation,
        )
        equalized = (fading * normalized + noise) / fading
        received = complex_to_real_per_image(equalized * scale, original_shape)
        if latent.rate_mask is not None:
            received = received * latent.rate_mask
            active = latent.rate_mask.reshape(latent.rate_mask.shape[0], -1).sum(dim=1)
            channel_uses = [int(value.item()) // 2 for value in active]
        else:
            channel_uses = [complex_symbols.shape[1]] * int(latent.tensor.shape[0])
        return TransmissionArtifact(
            transmitted=clean,
            received=received,
            channel_name=self.name,
            snr_db=float(snr_db),
            channel_uses_per_image=channel_uses,
            metadata={"snr_definition": "Es/N0_dB", "receiver": "perfect_csi_zero_forcing"},
        )
