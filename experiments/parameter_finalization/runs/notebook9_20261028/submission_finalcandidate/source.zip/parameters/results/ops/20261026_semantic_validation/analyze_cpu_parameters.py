"""Secondary source-label analysis of cached CPU outputs; no tuning or inference."""
import json
from pathlib import Path
from collections import Counter
import numpy as np
from BetterScheduler.image_claims import NATIVE_FACTS
from BetterScheduler.claim_repair_pilot import binary_metrics

ROOT=Path(__file__).resolve().parents[3]
SOURCE=ROOT/'results/local/semantic_validation_cpu_20261026h'
OUT=Path(__file__).resolve().parent
records=json.loads((SOURCE/'data/records.json').read_text(encoding='utf-8-sig'))
cached={r['image_id']:r['evidence'] for r in map(json.loads,(SOURCE/'extraction/features.jsonl').read_text().splitlines())}
report={};correct=0;compared=0
for native,fact in NATIVE_FACTS.items():
    truth=[];predicted=[];scores=[]
    for row in records:
        known=row['native_labels'].get(native)
        item=cached[row['image_id']]['provenance']['image_claim_predictions'].get(fact)
        if type(known) is bool and item:
            truth.append(known);predicted.append(item['value']);scores.append(item['score'])
    item=binary_metrics(truth,predicted)
    item['brier_descriptive_uncalibrated']=float(np.mean((np.array(scores)-np.array(truth))**2)) if truth else None
    report[fact]=item;correct+=sum(a==b for a,b in zip(truth,predicted));compared+=len(truth)
trace=json.loads((Path(str(SOURCE)+'_replay')/'extraction/trace.json').read_text())
metadata={'source':'12 balanced official-test-source images; development pilot',
    'all_native_heads_comparable':compared,'all_native_heads_correct':correct,
    'primary_building_heads_correct':24,'primary_building_heads_comparable':24,
    'analysis_json_bytes':[r['analysis_json_bytes'] for r in trace],
    'header_warning':'Analysis JSON byte counts are not a deployed binary header or latent payload.',
    'unknown_constructs':['natural event novelty','cross-view complementarity','semantic depth','physical proximity',
                          'calibrated importance','real freshness/geographic utility'],
    'per_head':report}
(OUT/'cpu_native_head_metrics.json').write_text(json.dumps(metadata,indent=2))
print(json.dumps(metadata,indent=2))

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
order={'absent':0,'present_unaffected':1,'affected':2}
rows=sorted(records,key=lambda r:(order[r['stratum']],r['source_row']))
facts=list(NATIVE_FACTS.items())
truth=np.array([[r['native_labels'][native] for native,fact in facts] for r in rows],dtype=int)
pred=np.array([[cached[r['image_id']]['provenance']['image_claim_predictions'][fact]['value'] for native,fact in facts] for r in rows],dtype=int)
labels=[fact.replace('building.affected_or_greater','building.affected+').replace('building.minor_or_greater','building.minor+') for native,fact in facts]
fig,axes=plt.subplots(1,2,figsize=(14,7),layout='constrained')
for ax,array,title in zip(axes,(truth,pred),('Published native labels','Frozen classifier predictions')):
    ax.imshow(array,cmap=ListedColormap(['#f2f3f5','#2667ad']),vmin=0,vmax=1,aspect='auto')
    ax.set_title(title);ax.set_xticks(range(len(labels)),labels,rotation=65,ha='right',fontsize=8)
    ax.set_yticks(range(len(rows)),[r['stratum']+' / row '+str(r['source_row']) for r in rows],fontsize=8)
    ax.set_xticks(np.arange(-.5,len(labels),1),minor=True);ax.set_yticks(np.arange(-.5,len(rows),1),minor=True)
    ax.grid(which='minor',color='white',linewidth=1);ax.tick_params(which='minor',bottom=False,left=False)
for i,j in zip(*np.where(truth!=pred)):
    axes[1].add_patch(plt.Rectangle((j-.46,i-.46),.92,.92,fill=False,edgecolor='#df4a3a',linewidth=2))
fig.suptitle(f'CPU pilot: {correct}/{compared} native facts match on 12 images (primary building facts: 24/24)\nBlue=true; pale=false; red outline=mismatch. Small development panel; no general accuracy claim.',fontsize=12)
fig.savefig(OUT/'cpu_native_head_comparison.png',dpi=180)
fig.savefig(OUT/'cpu_native_head_comparison.svg')
