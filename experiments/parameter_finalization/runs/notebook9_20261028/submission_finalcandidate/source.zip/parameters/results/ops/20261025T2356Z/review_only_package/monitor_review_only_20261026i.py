import hashlib,json,os,re,sys,time
from datetime import datetime,timezone
from pathlib import Path
from kaggle.api.kaggle_api_extended import KaggleApi
RUN=Path(__file__).resolve().parent
SLUG='satyapaladugu/betterscheduler-qwen9b-review-20261026i'
MAX_SECONDS=2100; POLL_SECONDS=60
TERMINAL={'COMPLETE','ERROR','FAILED','CANCELLED','CANCELED','STOPPED','TIMED_OUT'}
def utc(): return datetime.now(timezone.utc).isoformat()
def write(path,obj): path.write_text(json.dumps(obj,indent=2,ensure_ascii=True),encoding='utf-8')
def sname(x): return str(getattr(x,'status','UNKNOWN')).split('.')[-1].upper()
def retrieve(api,status,failure,elapsed):
 dest=RUN/'retrieved'; dest.mkdir(parents=True,exist_ok=True)
 pattern=r'(?i)(artifact_checksums\.json|.*\.(json|jsonl|log|txt|ipynb|jpg|png))'
 files,token=api.kernels_output(SLUG,str(dest),file_pattern=pattern,quiet=True,page_size=100,force=False)
 got=[]
 for raw in files:
  p=Path(raw)
  if p.is_file(): got.append({'path':str(p.relative_to(dest)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 cp=dest/'artifact_checksums.json'; manifest={};checked=[];missing=[];mismatch=[]
 if cp.is_file():
  manifest=json.loads(cp.read_text(encoding='utf-8-sig'))
  base=dest/'results'/'semantic_validation'/'20261026i'
  for rel,want in manifest.items():
   p=base/rel
   if not p.is_file(): missing.append(rel); continue
   actual=hashlib.sha256(p.read_bytes()).hexdigest()
   if actual.lower()==str(want).lower(): checked.append(rel)
   else: mismatch.append({'path':rel,'expected':want,'actual':actual})
 else: missing.append('artifact_checksums.json')
 names=[Path(x['path']).name.lower() for x in got]
 required={'status.json':any(x.endswith('/status.json') or x=='status.json' for x in names),'metrics.json':any(x.endswith('/metrics.json') or x=='metrics.json' for x in names),'artifact_checksums.json':'artifact_checksums.json' in names,'executed_notebook':any(x.endswith('.ipynb') for x in names),'cell_log':any('cell' in x and x.endswith(('.log','.txt')) for x in names)}
 receipt={'retrieved_utc':utc(),'kernel':SLUG,'terminal_status':status,'failure_message':failure,'elapsed_monitor_seconds':elapsed,'destination':str(dest),'pattern':pattern,'files_found':len(got),'files':got,'api_next_page_token':token,'run_checksum_entries':len(manifest),'checksum_verified':len(checked),'checksum_missing':missing,'checksum_mismatches':mismatch,'required_presence':required}
 write(RUN/'terminal_retrieval_receipt.json',receipt)
 return receipt
def main():
 start=time.monotonic();events=[];last=None;errors=0
 write(RUN/'monitor_pid.json',{'pid':os.getpid(),'started_utc':utc(),'kernel':SLUG,'max_monitor_seconds':MAX_SECONDS,'poll_seconds':POLL_SECONDS,'status_only_while_running':True})
 api=KaggleApi();api.authenticate()
 while time.monotonic()-start<MAX_SECONDS:
  elapsed=round(time.monotonic()-start,1)
  try:
   obj=api.kernels_status(SLUG);status=sname(obj);failure=getattr(obj,'failure_message',None);errors=0
   if status!=last:
    event={'utc':utc(),'status':status,'failure_message':failure,'elapsed_seconds':elapsed};events.append(event);write(RUN/'status_events.json',events);last=status;print(json.dumps(event,ensure_ascii=True),flush=True)
   if status in TERMINAL:
    receipt=retrieve(api,status,failure,elapsed);print(json.dumps({'terminal_status':status,'retrieved_files':receipt['files_found'],'verified':receipt['checksum_verified'],'missing':len(receipt['checksum_missing']),'mismatches':len(receipt['checksum_mismatches']),'required_presence':receipt['required_presence']},ensure_ascii=True),flush=True);return 0 if status=='COMPLETE' else 2
  except Exception as exc:
   errors+=1;print(json.dumps({'utc':utc(),'status_check_error':type(exc).__name__,'message':str(exc)[:500],'count':errors},ensure_ascii=True),flush=True)
   if errors>=3:
    write(RUN/'monitor_error.json',{'utc':utc(),'errors':errors,'status_events':events});return 3
  time.sleep(POLL_SECONDS)
 write(RUN/'monitor_timeout_receipt.json',{'utc':utc(),'last_status':last,'elapsed_seconds':round(time.monotonic()-start,1),'status_events':events,'terminal_retrieval_attempted':False});return 4
if __name__=='__main__':sys.exit(main())
