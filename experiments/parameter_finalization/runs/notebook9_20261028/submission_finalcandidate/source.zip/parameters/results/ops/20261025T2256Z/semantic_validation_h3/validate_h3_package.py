import ast,base64,hashlib,json,zipfile
from pathlib import Path
import nbformat
root=Path('.').resolve()
stage=root/'BetterScheduler/staging/20261026h3'
out=root/'BetterScheduler/results/ops/20261025T2256Z/semantic_validation_h3'
manifest=json.loads((stage/'pilot_manifest.json').read_text())
meta=json.loads((stage/'kernel-metadata.json').read_text())
config=json.loads((root/'BetterScheduler/config/semantic_validation_v1.json').read_text())
nb=nbformat.read(stage/'notebook.ipynb',as_version=4)
code=[c.source for c in nb.cells if c.cell_type=='code']
for i,src in enumerate(code): compile(src,f'cell_{i}','exec')
assert len(code)==4 and len([c for c in nb.cells if c.cell_type=='markdown'])==1
assert meta['id']=='satyapaladugu/betterscheduler-semantic-validation-20261026h3'
assert meta['is_private'] and meta['enable_gpu'] and meta['machine_shape']=='NvidiaTeslaT4' and meta['enable_internet'] and not meta['kernel_sources']
assert manifest['slug']==meta['id'] and manifest['server_seconds']==1200 and manifest['internal_seconds']==1050
assert abs(manifest['maximum_allocated_gpu_hours']-2*1200/3600)<1e-9 and manifest['upstream'] is None
assert manifest['source_manifest']['tag']=='20261026h3'
assert len(config['panel_records'])==12 and config['review_parents_per_stratum']==2
assert config['limits']['reviews_per_model']==30 and config['limits']['server_seconds']==1200 and config['limits']['internal_seconds']==1050
assert config['review_settings']['enable_thinking'] is False
assert config['models']['qwen4b']['revision']=='ebb281ec70b05090aa6165b016eac8ec08e71b17'
assert config['models']['qwen9b']['revision']=='c202236235762e1c871ad0ccb60c8ee5ba337b9a'
assert config['models']['qwen4b']['transformers']=='4.57.6' and config['models']['qwen9b']['transformers']=='5.3.0'
parsed=ast.parse(code[0])
call=next(n for n in ast.walk(parsed) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='b64decode')
embedded=base64.b64decode(ast.literal_eval(call.args[0]))
archive=(stage/'source.zip').read_bytes()
assert embedded==archive
hashes={};mismatches=[];missing=[];intentional=[]
with zipfile.ZipFile(stage/'source.zip') as z:
    zmanifest=json.loads(z.read('SOURCE_MANIFEST.json'))
    expected=manifest['source_manifest']['files']
    assert zmanifest['files']==expected
    for name,want in expected.items():
        data=z.read(name);got=hashlib.sha256(data).hexdigest();assert got==want,name;hashes[name]=got
        live=root/name
        if not live.is_file():missing.append(name)
        elif hashlib.sha256(live.read_bytes()).hexdigest()!=want:
            if name in {'INFRA/__init__.py','INFRA/learning/__init__.py','Scheduler/__init__.py'}: intentional.append(name)
            else: mismatches.append(name)
assert not missing and not mismatches,{'missing':missing,'mismatches':mismatches}
driver=(root/'BetterScheduler/semantic_validation_driver.py').read_text()
run_source=(root/'BetterScheduler/semantic_validation_run.py').read_text()
packed_config=(root/'BetterScheduler/config/semantic_validation_v1.json').read_text()
positions={token:driver.index(token) for token in ('--without-pip','--python','qwen35_import_preflight',"stage('03_baseline_4b')","stage('04_challenger_9b')")}
assert positions['--without-pip']<positions['--python']<positions['qwen35_import_preflight']<positions["stage('03_baseline_4b')"]<positions["stage('04_challenger_9b')"]
assert 'ensurepip' not in driver and 'reviews_per_model' in packed_config
assert 'select_review_cohort' in run_source and 'controls_evaluator_only.json' in run_source
assert 'server_seconds=1200' in code[2] and '20261026h3' in code[2]
receipt={'status':'passed','tag':manifest['source_manifest']['tag'],'commit':manifest['source_manifest']['commit'],'source_zip_sha256':hashlib.sha256(archive).hexdigest(),'source_zip_bytes':len(archive),'source_entries':len(hashes),'live_mismatches':mismatches,'missing_live_sources':missing,'intentional_namespace_stub_differences':intentional,'embedded_zip_exact_match':embedded==archive,'notebook_code_cells':len(code),'all_cells_compile':True,'kernel_private_t4_internet':True,'upstream_sources':[],'server_seconds':1200,'internal_seconds':1050,'aggregate_gpu_hours':2*1200/3600,'panel_records':len(config['panel_records']),'review_parents_per_stratum':config['review_parents_per_stratum'],'reviews_per_model':config['limits']['reviews_per_model'],'expected_review_calls_total':2*config['limits']['reviews_per_model'],'thinking_off':config['review_settings']['enable_thinking'] is False,'model_pins':{k:{'id':v['model_id'],'revision':v['revision'],'transformers':v['transformers']} for k,v in config['models'].items()},'nine_b_environment_gate_order':positions,'source_hashes':hashes}
(out/'package_validation.json').write_text(json.dumps(receipt,indent=2))
(out/'source_hashes.json').write_text(json.dumps({'tag':receipt['tag'],'commit':receipt['commit'],'hashes':hashes},indent=2))
print(json.dumps({k:v for k,v in receipt.items() if k not in ('source_hashes','nine_b_environment_gate_order')},indent=2))
