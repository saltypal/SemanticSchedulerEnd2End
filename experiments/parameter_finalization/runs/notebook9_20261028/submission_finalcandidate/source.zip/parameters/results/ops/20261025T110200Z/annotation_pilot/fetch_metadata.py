import hashlib,json,pathlib,sys
from kaggle import KaggleApi
from kagglesdk.kernels.types.kernels_api_service import ApiDownloadKernelOutputRequest
root=pathlib.Path(sys.argv[1]);root.mkdir(parents=True,exist_ok=True)
files={
 'status.json':'results/prepare/20261025b/status.json',
 'config.json':'results/prepare/20261025b/config.json',
 'source_availability.json':'results/prepare/20261025b/data/source_availability.json',
 'records.json':'results/prepare/20261025b/data/records.json',
 'exposure_audit.json':'results/prepare/20261025b/data/exposure_audit.json',
 'exposure_ledger.json':'results/prepare/20261025b/data/exposure_ledger.json',
 'conflicting_annotations.json':'results/prepare/20261025b/data/conflicting_annotations.json',
 'annotation_preflight.json':'results/prepare/20261025b/data/ladi/annotation_preflight.json',
 'artifact_checksums.json':'artifact_checksums.json',
}
api=KaggleApi();api.authenticate()
rows=[]
with api.build_kaggle_client() as client:
 for name,path in files.items():
  req=ApiDownloadKernelOutputRequest();req.owner_slug='satyapaladugu';req.kernel_slug='betterscheduler-prepare-20261025b';req.file_path=path
  response=client.kernels.kernels_api_client.download_kernel_output(req)
  if response.status_code != 200: raise RuntimeError(f'{name}: HTTP {response.status_code}')
  data=response.content
  target=root/name;target.write_bytes(data)
  rows.append({'name':name,'remote_path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(root/'download_receipts.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows,indent=2))
