from kaggle import KaggleApi
from kagglesdk.kernels.types.kernels_api_service import ApiDownloadKernelOutputRequest
api=KaggleApi();api.authenticate();
with api.build_kaggle_client() as c:
 q=ApiDownloadKernelOutputRequest();q.owner_slug='satyapaladugu';q.kernel_slug='betterscheduler-prepare-20261025b';q.file_path='results/prepare/20261025b/status.json';r=c.kernels.kernels_api_client.download_kernel_output(q)
 print({'type':str(type(r)),'has_url':hasattr(r,'url'),'status':getattr(r,'status_code',None),'content_length_header':getattr(r,'headers',{}).get('Content-Length') if hasattr(r,'headers') else None,'content_bytes':len(getattr(r,'content',b''))})
