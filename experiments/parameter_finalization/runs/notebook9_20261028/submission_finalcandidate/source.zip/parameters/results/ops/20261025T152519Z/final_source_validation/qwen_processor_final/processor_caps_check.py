import hashlib,json,time,sys
from pathlib import Path
from PIL import Image,ImageOps
from transformers import AutoProcessor
from BetterScheduler.qwen_reviewer import load_review_processor,build_review_messages,pixel_input_receipt
from BetterScheduler.model_settings import ReviewerSettings
from BetterScheduler.annotation_review import review_system_prompt
from BetterScheduler.pilot_producers import file_sha256
rev='ebb281ec70b05090aa6165b016eac8ec08e71b17'
model=Path(r'C:\Users\satya\.cache\huggingface\hub\models--Qwen--Qwen3-VL-4B-Instruct\snapshots')/rev
image_path=Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\ops\20261025T142100Z\actual_extraction_diagnostic\official_ladi_test\images\50ddbba57b12c710ef2b12849ee69e9ef9b35cadc76abd39ba8f1a5daa39194b.jpg')
assert file_sha256(image_path)=='50ddbba57b12c710ef2b12849ee69e9ef9b35cadc76abd39ba8f1a5daa39194b'
source=Image.open(image_path).convert('RGB')
rows=[]; start=time.perf_counter()
for cap in (262144,589824):
    settings=ReviewerSettings(max_pixels=cap)
    processor=load_review_processor(model,settings)
    assert processor.image_processor.size=={'shortest_edge':min(65536,cap),'longest_edge':cap}
    for side in (512,None):
        picture=source if side is None else ImageOps.contain(source,(side,side))
        for variant in ('candidate_provenance_v2','candidate_provenance_concise_v3'):
            content=[{'type':'image','image':picture},{'type':'text','text':'Assess only the required building claims in this current aerial image. Report evidence and uncertainty in the specified JSON schema.'}]
            msgs=build_review_messages(content,variant)
            inp=processor.apply_chat_template(msgs,tokenize=True,add_generation_prompt=True,return_dict=True,return_tensors='pt')
            rec=pixel_input_receipt(inp,processor,cap)
            assert rec['processed_image_pixels'][0] <= cap
            rows.append({'cap':cap,'image_max_side':side,'prompt_variant':variant,'provided_image_size':list(picture.size),'input_tokens':int(inp['input_ids'].shape[1]),**rec})
result={'status':'passed','model_revision':rev,'transformers':__import__('transformers').__version__,'weights_loaded':False,'generation_called':False,'source_image_sha256':file_sha256(image_path),'source_image_size':list(source.size),'cases':len(rows),'cases_detail':rows,'seconds':time.perf_counter()-start,'note':'Actual cached processor loaded through production load_review_processor; no image/model weights loaded, no generation.'}
out=Path(sys.argv[1]);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))

