import json,pathlib,hashlib
base=pathlib.Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\cloud_annotation_pilot\20261025e')
nb=json.loads((base/'cell_evidence/executed.ipynb').read_text(encoding='utf-8'))
cells=[]
for i,c in enumerate(nb.get('cells',[])):
 errors=[{'ename':o.get('ename'),'evalue':o.get('evalue')} for o in c.get('outputs',[]) if o.get('output_type')=='error']
 cells.append({'index':i,'cell_type':c.get('cell_type'),'execution_count':c.get('execution_count'),'outputs':len(c.get('outputs',[])),'errors':errors})
files=[]
for p in sorted(x for x in base.rglob('*') if x.is_file()):
 data=p.read_bytes();files.append({'path':p.relative_to(base).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
out={'executed_notebook':{'path':'cell_evidence/executed.ipynb','cells':len(cells),'executed_cells':sum(c['execution_count'] is not None for c in cells),'error_cells':sum(bool(c['errors']) for c in cells),'cell_summary':cells},'local_retrieved_file_count':len(files),'total_bytes':sum(x['bytes'] for x in files),'files':files}
(base.parent.parent/'notebook_and_local_files_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k!='files'},indent=2))
