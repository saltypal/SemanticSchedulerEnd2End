"""Bounded annotation-assisted Qwen review,explicitly on GPU1."""
from pathlib import Path
from dataclasses import replace,asdict
import hashlib
import json
import time
from .annotation_review import reviewer_input,parse_review,review_system_prompt,REVIEW_PROTOCOL
from .model_settings import ReviewerSettings
from .contracts import digest
from .pilot_producers import file_sha256


def build_review_messages(content,prompt_variant=REVIEW_PROTOCOL):
    """Multimodal ProcessorMixin requires typed content lists for every role."""
    return [{'role':'system','content':[{'type':'text','text':review_system_prompt(prompt_variant)}]},
            {'role':'user','content':content}]


def load_review_processor(model_path,settings):
    """Fast Qwen image processors use size, not a late-set max_pixels alias."""
    from transformers import AutoProcessor
    size={'shortest_edge':min(65536,settings.max_pixels),'longest_edge':settings.max_pixels}
    processor=AutoProcessor.from_pretrained(str(model_path),local_files_only=True,size=size)
    if dict(processor.image_processor.size)!=size:raise ValueError('review processor did not apply the requested pixel budget')
    return processor


def pixel_input_receipt(inputs,processor,max_pixels):
    grid=inputs.get('image_grid_thw')
    if grid is None:raise RuntimeError('reviewer image-grid metadata absent')
    patch=int(processor.image_processor.patch_size)
    areas=[int(row[1])*int(row[2])*patch*patch for row in grid.detach().cpu().tolist()]
    if any(area>max_pixels for area in areas):raise RuntimeError('reviewer actual image pixels exceeded configured budget')
    return {'pixel_tensor_shape':list(inputs['pixel_values'].shape),
        'image_grid_thw':grid.detach().cpu().tolist(),'processed_image_pixels':areas,
        'pixel_tensor_sha256':hashlib.sha256(inputs['pixel_values'].detach().cpu().contiguous().numpy().tobytes()).hexdigest()}


class QwenAnnotationReviewer:
    def __init__(self,model_path,revision,device='cuda:1',max_new_tokens=None,settings=None):
        if device!='cuda:1':raise ValueError('reviewer must explicitly own GPU1')
        self.model_path,self.revision,self.device=str(model_path),revision,device
        self.settings=settings or ReviewerSettings()
        if max_new_tokens is not None:self.settings=replace(self.settings,max_new_tokens=max_new_tokens)
        self.max_new_tokens=self.settings.max_new_tokens;self.loaded=False

    def load(self):
        if self.loaded:return
        import torch
        from transformers import Qwen3VLForConditionalGeneration
        if torch.cuda.device_count()<2:raise RuntimeError('two assigned GPUs required')
        self.torch=torch;started=time.perf_counter()
        self.processor=load_review_processor(self.model_path,self.settings)
        self.model=Qwen3VLForConditionalGeneration.from_pretrained(self.model_path,local_files_only=True,
            torch_dtype=torch.float16,attn_implementation='sdpa',device_map={'':self.device}).eval()
        devices=sorted({str(p.device) for p in self.model.parameters()})
        if devices!=[self.device]:raise RuntimeError('reviewer placement is not exclusively GPU1: '+str(devices))
        weights={p.name:file_sha256(p) for p in Path(self.model_path).glob('*.safetensors')}
        self.provenance={'model_id':'Qwen/Qwen3-VL-4B-Instruct','revision':self.revision,
            'weights_sha256':weights,'device':self.device,'dtype':'float16','attention':'sdpa',
            'max_image_pixels':self.settings.max_pixels,'max_new_tokens':self.max_new_tokens,
            'do_sample':False,'load_seconds':time.perf_counter()-started,'parameter_devices':devices,
            'mode':'annotation_assisted_visible_json','not_independent_ground_truth':True}
        self.provenance.update(review_protocol=self.settings.prompt_variant,settings=asdict(self.settings),
            effective_processor_size=dict(self.processor.image_processor.size),
            system_prompt_sha256=digest(review_system_prompt(self.settings.prompt_variant)))
        self.loaded=True

    def configure(self,settings):
        """Change a recorded search setting without reloading the model weights."""
        if not isinstance(settings,ReviewerSettings):raise TypeError('ReviewerSettings required')
        if not self.loaded:
            self.settings=settings;self.max_new_tokens=settings.max_new_tokens;self.load();return
        if settings.max_pixels!=self.settings.max_pixels:
            self.processor=load_review_processor(self.model_path,settings)
        self.settings=settings;self.max_new_tokens=settings.max_new_tokens
        self.provenance.update(max_image_pixels=settings.max_pixels,max_new_tokens=settings.max_new_tokens,
            effective_processor_size=dict(self.processor.image_processor.size),
            review_protocol=settings.prompt_variant,settings=asdict(settings),
            system_prompt_sha256=digest(review_system_prompt(settings.prompt_variant)))

    def review(self,image_paths,candidate,reference,mission,rubric,history,case_id,raw_dir,
               text_only_diagnostic=False):
        if bool(image_paths)==bool(text_only_diagnostic):
            raise ValueError('supply images for visual review, or explicitly request the text-only diagnostic')
        self.load()
        from PIL import Image,ImageOps
        raw_dir=Path(raw_dir);raw_dir.mkdir(parents=True,exist_ok=True)
        payload=reviewer_input(candidate,reference,mission,rubric,history,claim_scope=self.settings.claim_scope)
        payload['review_protocol']=self.settings.prompt_variant
        content=[];images=[];receipts=[]
        # Current image is first;past image identifiers are logged in history.
        for path in image_paths:
            with Image.open(path) as image:
                picture=image.convert('RGB')
                if self.settings.image_max_side is not None:
                    picture=ImageOps.contain(picture,(self.settings.image_max_side,self.settings.image_max_side))
            images.append(picture);content.append({'type':'image','image':picture})
            receipts.append({'sha256':file_sha256(path),'supplied_size':list(picture.size)})
        prefix=('Text-only protocol diagnostic; no image is supplied. Use the provided candidate and reference.\n'
                if text_only_diagnostic else
                'Image1 is the current observation; subsequent images are declared past views.\n')
        content.append({'type':'text','text':prefix+json.dumps(payload,allow_nan=False)})
        messages=build_review_messages(content,self.settings.prompt_variant)
        start=time.perf_counter();raw='';inputs=None;generation={}
        try:
            inputs=self.processor.apply_chat_template(messages,tokenize=True,add_generation_prompt=True,
                        return_dict=True,return_tensors='pt').to(self.device)
            if not text_only_diagnostic and ('pixel_values' not in inputs or inputs['pixel_values'].numel()==0):
                raise RuntimeError('vision pixels absent from reviewer input')
            generation=({'text_only_diagnostic':True} if text_only_diagnostic else
                        pixel_input_receipt(inputs,self.processor,self.settings.max_pixels))
            self.torch.cuda.synchronize(1);self.torch.cuda.reset_peak_memory_stats(1)
            with self.torch.inference_mode():
                generated=self.model.generate(**inputs,max_new_tokens=self.max_new_tokens,do_sample=False)
            self.torch.cuda.synchronize(1)
            tokens=generated[0,inputs['input_ids'].shape[1]:]
            eos=self.model.generation_config.eos_token_id
            eos=[] if eos is None else [eos] if isinstance(eos,int) else eos
            generation.update(generated_tokens=len(tokens),input_tokens=int(inputs['input_ids'].shape[1]),
                hit_token_limit=len(tokens)>=self.max_new_tokens and (not len(tokens) or int(tokens[-1]) not in eos))
            raw=self.processor.decode(tokens,skip_special_tokens=True).strip()
            raw_path=raw_dir/(case_id+'.txt');raw_path.write_text(raw,encoding='utf-8')
            parsed,recovered=parse_review(raw)
            return {'case_id':case_id,'status':'complete','parsed':parsed,'raw_response_ref':str(raw_path),
                    'parse_recovery_used':recovered,'wall_seconds':time.perf_counter()-start,
                    **generation,'image_inputs':receipts,
                    'prompt_sha256':digest({'system':review_system_prompt(self.settings.prompt_variant),'user':payload}),
                    'review_protocol':self.settings.prompt_variant,'peak_gpu1_bytes':self.torch.cuda.max_memory_allocated(1),
                    'assessment_kind':('text_only_protocol_diagnostic' if text_only_diagnostic else
                                       'annotation_assisted_model_review'),'model_revision':self.revision}
        except Exception as error:
            path=raw_dir/(case_id+'.failure.json')
            path.write_text(json.dumps({'error':type(error).__name__,'message':str(error),'raw':raw},indent=2))
            return {'case_id':case_id,'status':'parse_failed' if raw else 'model_failed',
                    'error':type(error).__name__,'message':str(error),'raw_response_ref':str(path),
                    'wall_seconds':time.perf_counter()-start,'image_inputs':receipts,**generation,
                    'review_protocol':self.settings.prompt_variant}
        finally:
            del inputs

    def close(self):
        if hasattr(self,'model'):del self.model
        if hasattr(self,'processor'):del self.processor
        import gc
        gc.collect()
        if hasattr(self,'torch'):self.torch.cuda.empty_cache()
