class YOLOWorld:
 def __init__(self,*a,**k): raise AssertionError("inference forbidden")
