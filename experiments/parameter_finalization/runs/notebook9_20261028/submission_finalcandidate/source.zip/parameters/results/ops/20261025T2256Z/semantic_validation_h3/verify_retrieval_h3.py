import hashlib,json,re,sys
from pathlib import Path
from kaggle.api.kaggle_api_extended import KaggleApi
if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8',errors='backslashreplace')
if hasattr(sys.stderr,'reconfigure'):sys.stderr.reconfigure(encoding='utf-8',errors='backslashreplace')
ops=Path(__file__).resolve().parent;stage=Path(__file__).resolve().parents[5]/'BetterScheduler/staging/20261026h3';tag=json.loads((stage/'pilot_manifest.json').read_text())['source_manifest']['tag'];slug=json.loads((stage/'pilot_manifest.json').read_text())['slug'];dest=ops/'monitor'/'retrieved'
pattern=r'(?i)(^|/)(artifact_checksums\.json|checksums\.json|status\.json|summary\.json|metrics\.json|hardware\.json|manifest\.json|config\.json|progress\.json|cell_status\.json|dependency_receipt\.json|processor_preflight\.json|executed\.ipynb|.*\.jsonl|.*\.log|.*\.txt|.*\.csv|.*\.png|.*\.jpg|.*\.json)$'
api=KaggleApi();api.authenticate();files,token=api.kernels_output(slug,str(dest),file_pattern=pattern,quiet=True,page_size=100,force=False)
root=dest/'results'/'semantic_validation'/tag
def verify(base,manifest_path):
    result={'manifest':str(manifest_path.relative_to(dest)),'entries':0,'verified':0,'missing':[],'mismatches':[]}
    if not manifest_path.is_file():result['missing'].append(str(manifest_path));return result
    checks=json.loads(manifest_path.read_text(encoding='utf-8'));result['entries']=len(checks)
    for rel,want in checks.items():
        p=base/rel
        if not p.is_file():result['missing'].append(rel)
        else:
            got=hashlib.sha256(p.read_bytes()).hexdigest()
            if got==want:result['verified']+=1
            else:result['mismatches'].append({'path':rel,'expected':want,'actual':got})
    return result
inventory=[]
for raw in files:
    p=Path(raw)
    if p.is_file():inventory.append({'path':str(p.relative_to(dest)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
receipt={'utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),'kernel':slug,'tag_derived_from_manifest':tag,'python_utf8':True,'file_pattern':pattern,'returned_paths':len(files),'page_token_returned':bool(token),'inventory':inventory,'global_checksum':verify(root,dest/'artifact_checksums.json'),'run_checksum':verify(root,root/'checksums.json'),'executed_notebook_present':(dest/'cell_evidence/executed.ipynb').is_file(),'cell_logs_present':sum((dest/'cell_evidence'/f'cell_{i}.log').is_file() for i in range(4)),'image_count':len(list((root/'data/images').glob('*.jpg')))}
(ops/'retrieval_verification.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=True),encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('inventory','file_pattern')},indent=2))
