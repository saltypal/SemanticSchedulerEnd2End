"""The final four-output candidate; old eight-field extractors stay historical.

Query has no KB side effects. Commit only after serialization/acceptance succeeds.
The 28-byte wire layout is an additive experimental protocol, not a radio format.
"""
from dataclasses import dataclass
import math
import struct
import numpy as np

from .extractor import unit, embedding_signature
from .pilot_parameters import context_similarity_key

WIRE = struct.Struct("<BBHIIHQIBB")


@dataclass(frozen=True)
class MinimalHeader:
    source: int
    session: int
    message: int
    profile: int
    scheduling_class: int | None = None  # 0 Critical, 1 High, 2 Medium, 3 Low
    relevance: float | None = None      # raw image/text cosine, [-1,1]
    novelty: float | None = None        # appearance distance, [0,1]
    capture_time_ms: int | None = None
    allowed_delay_ms: int | None = None
    cold_start: bool = False

    def __post_init__(self):
        for key,bits in (("source",16),("session",32),("message",32),("profile",16)):
            value=getattr(self,key)
            if type(value) is not int or not 0<=value<2**bits: raise ValueError("invalid routing field: "+key)
        if self.scheduling_class is not None and (type(self.scheduling_class) is not int or not 0<=self.scheduling_class<=3):
            raise ValueError("invalid scheduling class")
        for name,low,high in (("relevance",-1,1),("novelty",0,1)):
            value=getattr(self,name)
            if value is not None and (isinstance(value,bool) or not math.isfinite(value) or not low<=value<=high):
                raise ValueError("invalid "+name)
        for name,bits in (("capture_time_ms",64),("allowed_delay_ms",32)):
            value=getattr(self,name)
            if value is not None and (type(value) is not int or not 0<value<2**bits): raise ValueError("invalid "+name)
        if type(self.cold_start) is not bool or self.cold_start and self.novelty is None:
            raise ValueError("cold start requires available novelty")

    def to_bytes(self):
        flags=(self.scheduling_class or 0)
        for bit,value in ((2,self.scheduling_class),(3,self.relevance),(4,self.novelty),(5,self.capture_time_ms),(6,self.allowed_delay_ms)):
            if value is not None: flags|=1<<bit
        if self.cold_start:flags|=128
        r=0 if self.relevance is None else round((self.relevance+1)*127.5)
        n=0 if self.novelty is None else round(self.novelty*255)
        return WIRE.pack(1,flags,self.source,self.session,self.message,self.profile,
                         self.capture_time_ms or 0,self.allowed_delay_ms or 0,r,n)

    @classmethod
    def from_bytes(cls, payload):
        if len(payload)!=WIRE.size:raise ValueError("minimal header must be exactly 28 bytes")
        version,f,source,session,message,profile,capture,delay,r,n=WIRE.unpack(payload)
        if version!=1:raise ValueError("unsupported minimal-header version")
        return cls(source,session,message,profile,(f&3) if f&4 else None,
                   r/127.5-1 if f&8 else None,n/255 if f&16 else None,
                   capture if f&32 else None,delay if f&64 else None,bool(f&128))


class MinimalParameterExtractor:
    def __init__(self, provider=None, spi_classifier=None):
        self.provider,self.spi_classifier=provider,spi_classifier

    def extract(self, image, mission, metadata, memory):
        if self.provider is None:raise RuntimeError("visual provider required")
        evidence=self.provider.extract_batch([image],[mission])[0]
        return self.extract_evidence(evidence,mission,metadata,memory)

    def extract_evidence(self,evidence,mission,metadata,memory):
        if memory.source_id!=metadata.get("source_id") or memory.mission_id!=mission.mission_id:
            raise ValueError("source/mission KB identity mismatch")
        vector=unit(evidence.embedding); signature=embedding_signature(evidence)
        spi={"available":False,"level":None,"scheduling_class":None,"reason":"SPI model artifact not loaded"}
        if self.spi_classifier is not None:
            try:
                if vector is None:raise ValueError("image embedding unavailable")
                spi=self.spi_classifier.predict(vector,signature)
            except (ValueError,FloatingPointError) as error:
                spi={"available":False,"level":None,"scheduling_class":None,"reason":str(error)}
        relevance=evidence.similarities.get(context_similarity_key(mission))
        if relevance is not None and (not math.isfinite(relevance) or not -1.00001<=relevance<=1.00001):relevance=None
        if relevance is not None:relevance=float(np.clip(relevance,-1,1))
        previous=[r["embedding"] for r in memory.entries if r["embedding"] is not None and
                  r["embedding"].shape==(vector.shape if vector is not None else ()) and r["embedding_signature"]==signature]
        cold=vector is not None and not memory.entries
        novelty=1. if cold else ((1-float(np.clip(max(vector@v for v in previous),-1,1)))/2 if previous else None)
        captured=metadata.get("capture_time_ms")
        if metadata.get("timestamp_trusted") is not True or type(captured) is not int or captured<=0:captured=None
        now=metadata.get("now_ms")
        if captured is not None and type(now) is int and captured>now:captured=None
        header=MinimalHeader(metadata["source_numeric_id"],metadata["session_id"],metadata["message_id"],
            metadata["profile_id"],spi["scheduling_class"],relevance,novelty,captured,mission.allowed_delay_ms,cold)
        return {"schema":"better_minimal_parameters_v1","spi":spi,
                "relevance":{"available":relevance is not None,"cosine":relevance,"is_probability":False},
                "novelty":{"available":novelty is not None,"value":novelty,"cold_start":cold,
                           "meaning":"appearance difference from this UE's prior embeddings; not verified new facts"},
                "capture":{"capture_time_ms":captured,"allowed_delay_ms":mission.allowed_delay_ms},
                "header":header,"kb_version":memory.version,"feature_signature":signature}

    def serialize_and_commit(self,evidence,mission,metadata,memory):
        bundle=self.extract_evidence(evidence,mission,metadata,memory)
        payload=bundle["header"].to_bytes()
        memory.commit(evidence,metadata["sequence"])
        return bundle,payload
