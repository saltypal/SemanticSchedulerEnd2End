import json,pathlib,hashlib
from kaggle import KaggleApi
from kagglesdk.kernels.types.kernels_api_service import ApiDownloadKernelOutputRequest
root=pathlib.Path(__file__).parent/'named_outputs';root.mkdir(exist_ok=True)
paths=['cell_evidence/cell_status.json','processor_preflight.json']
api=KaggleApi();api.authenticate();receipts=[]
with api.build_kaggle_client() as client:
    for remote in paths:
        req=ApiDownloadKernelOutputRequest();req.owner_slug='satyapaladugu';req.kernel_slug='betterscheduler-annotation-pilot-20261025e';req.file_path=remote
        try:
            response=client.kernels.kernels_api_client.download_kernel_output(req)
            data=response.content
            receipt={'remote_path':remote,'http_status':response.status_code,'bytes':len(data)}
            if response.status_code==200:
                dest=root/pathlib.PurePosixPath(remote).name;dest.write_bytes(data)
                receipt.update(local_path=str(dest),sha256=hashlib.sha256(data).hexdigest())
                try:receipt['json']=json.loads(data.decode('utf-8'))
                except Exception:receipt['decode']='not-json-or-unavailable'
        except Exception as error:
            receipt={'remote_path':remote,'exception_type':type(error).__name__,'message':str(error)[:500]}
        receipts.append(receipt)
(root/'receipt.json').write_text(json.dumps(receipts,indent=2),encoding='utf-8')
print(json.dumps(receipts,indent=2))
