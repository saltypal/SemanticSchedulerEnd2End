class AutoProcessor:
 @classmethod
 def from_pretrained(cls,*a,**k): raise AssertionError("inference forbidden")
class Qwen3VLForConditionalGeneration: pass
