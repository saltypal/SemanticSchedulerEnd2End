import json,pathlib,collections
root=pathlib.Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\cloud_annotation_pilot\20261025e\results\annotation_pilot\20261025e')
def load(name):return [json.loads(s) for s in (root/name).read_text(encoding='utf-8').splitlines() if s]
controls=load('reviews/control_reviews.jsonl');params=load('reviews/parameter_reviews.jsonl')
summary={'controls':{'n':len(controls),'statuses':dict(collections.Counter(r.get('status','missing') for r in controls))},'parameters':{},'direct_fact_accuracy':{}}
for view in ('compact','structured'):
 g=[r for r in params if r.get('view')==view];valid=[r for r in g if (r.get('review') or {}).get('status')=='complete'];
 summary['parameters'][view]={'attempts':len(g),'review_statuses':dict(collections.Counter((r.get('review') or {}).get('status','missing') for r in g)),'consistent_true':sum((r.get('review') or {}).get('parsed',{}).get('parameters_consistent') is True for r in valid),'sufficient_true':sum((r.get('review') or {}).get('parsed',{}).get('representation_sufficient') is True for r in valid)}
 facts=collections.defaultdict(lambda:{'n':0,'correct':0,'tp':0,'tn':0,'fp':0,'fn':0,'unknown_pred_or_ref':0})
 for r in g:
  for c in r.get('direct_reference_metrics',{}).get('comparisons',[]):
   x=facts[c['fact']];x['n']+=1;pred=c['prediction'];ref=c['reference'];x['correct']+=int(pred==ref)
   if ref is True and pred is True:x['tp']+=1
   elif ref is False and pred is False:x['tn']+=1
   elif ref is False and pred is True:x['fp']+=1
   elif ref is True and pred is False:x['fn']+=1
   else:x['unknown_pred_or_ref']+=1
 summary['direct_fact_accuracy'][view]={k:{**v,'accuracy':v['correct']/v['n'] if v['n'] else None} for k,v in facts.items()}
summary['invalid_cases']=[{'case_id':r.get('case_id'),'view':r.get('view'),'status':(r.get('review') or {}).get('status'),'error':(r.get('review') or {}).get('error'),'message':(r.get('review') or {}).get('message')} for r in params if (r.get('review') or {}).get('status')!='complete']
out=root.parent.parent/'detailed_review_audit.json';out.write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary,indent=2))
