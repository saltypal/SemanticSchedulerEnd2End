import json
from collections import Counter
from pathlib import Path
root=Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\ops\20261025T2256Z\semantic_validation_h3\monitor\retrieved\results\semantic_validation\20261026h3')
for model in ('qwen4b','qwen9b'):
 p=root/model/'reviews.jsonl'; rows=[json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()] if p.exists() else []
 print(model,'rows',len(rows),'status',dict(Counter(r.get('status') for r in rows)),'arm',dict(Counter(r.get('arm') for r in rows)),'actual_rows',sum(r.get('arm')=='actual' for r in rows))
 print('noncomplete',[{'case_id':r.get('case_id'),'status':r.get('status'),'reason':r.get('reason'),'error':r.get('error')} for r in rows if r.get('status')!='complete'][:10])
 print('actual_case_rows',[r.get('case_id') for r in rows if r.get('arm')=='actual'])
