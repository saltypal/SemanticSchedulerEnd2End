import hashlib,json,pathlib
from kaggle import KaggleApi
from kagglesdk.kernels.types.kernels_api_service import ApiDownloadKernelOutputRequest
root=pathlib.Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\cloud_annotation_pilot\20261025e')
base='results/annotation_pilot/20261025e/'
files={
 'status.json':base+'status.json',
 'progress.json':base+'progress.json',
 'metrics/control_metrics.json':base+'metrics/control_metrics.json',
 'metrics/control_progress.json':base+'metrics/control_progress.json',
 'metrics/parameter_summary.json':base+'metrics/parameter_summary.json',
 'metrics/producer_timing.json':base+'metrics/producer_timing.json',
 'metrics/reviewer_technical_preflight.json':base+'metrics/reviewer_technical_preflight.json',
 'models/producer.json':base+'models/producer.json',
 'models/reviewer.json':base+'models/reviewer.json',
 'logs/00_data_and_reference_preflight.log':base+'logs/00_data_and_reference_preflight.log',
 'logs/01_reviewer_load_and_vision_preflight.log':base+'logs/01_reviewer_load_and_vision_preflight.log',
 'logs/02_annotation_assisted_reviewer_controls.log':base+'logs/02_annotation_assisted_reviewer_controls.log',
 'logs/03_gpu0_parameter_producer.log':base+'logs/03_gpu0_parameter_producer.log',
 'logs/04_parameters_histories_and_binary_reviews.log':base+'logs/04_parameters_histories_and_binary_reviews.log',
 'artifact_checksums.json':'artifact_checksums.json',
 'cell_evidence/cell_status.json':'cell_evidence/cell_status.json',
 'cell_evidence/executed.ipynb':'cell_evidence/executed.ipynb',
 'cell_evidence/cell_0.log':'cell_evidence/cell_0.log',
 'cell_evidence/cell_1.log':'cell_evidence/cell_1.log',
 'cell_evidence/cell_2.log':'cell_evidence/cell_2.log',
 'cell_evidence/cell_3.log':'cell_evidence/cell_3.log',
}
api=KaggleApi();api.authenticate();receipts=[]
with api.build_kaggle_client() as client:
 for relative,remote in files.items():
  req=ApiDownloadKernelOutputRequest();req.owner_slug='satyapaladugu';req.kernel_slug='betterscheduler-annotation-pilot-20261025e';req.file_path=remote
  try:
   response=client.kernels.kernels_api_client.download_kernel_output(req)
   data=response.content
   if response.status_code==200:
    destfile=root/relative;destfile.parent.mkdir(parents=True,exist_ok=True);destfile.write_bytes(data)
    receipts.append({'path':relative,'remote':remote,'http':200,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
   else:receipts.append({'path':relative,'remote':remote,'http':response.status_code,'bytes':len(data)})
  except Exception as e:
   # Suppress signed URLs and auth tokens in SDK exception text.
   name=type(e).__name__;msg=str(e).split(' for url:')[0][:180]
   receipts.append({'path':relative,'remote':remote,'exception':name,'message':msg})
(root.parent/'retrieval_receipts_core.json').write_text(json.dumps(receipts,indent=2),encoding='utf-8')
print(json.dumps(receipts,indent=2))
