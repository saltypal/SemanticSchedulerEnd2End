import json,hashlib,pathlib,collections,math
base=pathlib.Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler')
prepared_path=base/'results/ops/20261025T110200Z/annotation_pilot/records.json'
local_path=base/'results/local/20261025T082051Z/data/records.json'
e=base/'results/cloud_annotation_pilot/20261025e/results/annotation_pilot/20261025e'
read_json=lambda p:json.loads(p.read_text(encoding='utf-8'))
prepared=read_json(prepared_path);local=read_json(local_path)
prepared_by={r['image_id']:r for r in prepared};local_by={r['image_id']:r for r in local}
features=[json.loads(x) for x in (e/'features/evidence.jsonl').read_text(encoding='utf-8').splitlines() if x]
params=[json.loads(x) for x in (e/'parameters/parameters.jsonl').read_text(encoding='utf-8').splitlines() if x]
exposure=read_json(e/'data/development_exposure.json');cases=read_json(e/'data/control_cases_evaluator_only.json')
source_obs=collections.Counter(prepared_by[r['image_id']]['source'] for r in params)
obs_by=collections.defaultdict(list)
for r in params:obs_by[prepared_by[r['image_id']]['source']].append(r)
# The same annotated image may occur in multiple UE sequences; report observations, unique image IDs, and source groups separately.
obs_counts={}
for source,rows in obs_by.items():
 ids={r['image_id'] for r in rows};groups={prepared_by[i].get('group') for i in ids}
 entry={'observations':len(rows),'unique_image_ids':len(ids),'unique_parent_ids':len({prepared_by[i].get('parent_id') for i in ids}),
        'unique_groups':len(groups),'positive_observation_rows':{},'positive_unique_images':{},'positive_unique_groups':{},'task_missions':dict(collections.Counter(r['bundle']['mission_id'] for r in rows))}
 for claim in ('building_damage','road_damage'):
  pos=[r for r in rows if prepared_by[r['image_id']]['labels'].get(claim)==1]
  entry['positive_observation_rows'][claim]=len(pos)
  entry['positive_unique_images'][claim]=len({r['image_id'] for r in pos})
  entry['positive_unique_groups'][claim]=len({prepared_by[r['image_id']].get('group') for r in pos})
 obs_counts[source]=entry
feature_ids={x['image_id'] for x in features};feature_records={i:prepared_by[i] for i in feature_ids}
model_rows=[]
for x in features:
 i=x['image_id'];rec=prepared_by[i];ev=x['evidence'];dets=ev.get('detections') or [];labels=collections.Counter(d['label'] for d in dets)
 contrasts=ev.get('provenance',{}).get('condition_contrasts',{})
 model_rows.append({'image_id':i,'source':rec['source'],'group':rec.get('group'),'path_remote':rec['image_path'],
  'local_path':local_by.get(i,{}).get('image_path'),'local_match':i in local_by,'labels':rec['labels'],'native_labels':rec.get('native_labels',{}),
  'yolo_detection_count':len(dets),'yolo_detection_labels':dict(labels),'yolo_building_present':bool(labels.get('building',0)),
  'yolo_road_present':bool(labels.get('road',0)),'yolo_detections':dets,
  'clip_conditions':{key:{'positive':float(value['positive_similarity']),'negative':float(value['negative_similarity']),
      'proxy_positive':bool(value['positive_similarity']>value['negative_similarity']),'calibrated':value.get('calibrated',False)} for key,value in contrasts.items()}})
# Compare object-present detections with native presence labels (not damage classifications).
detection_eval={}
for concept,native_key,det_key in [('building','buildings_any','yolo_building_present'),('road','roads_any','yolo_road_present')]:
 rows=[r for r in model_rows if type(r['native_labels'].get(native_key)) is bool]
 tp=sum(r[det_key] and r['native_labels'][native_key] for r in rows);tn=sum((not r[det_key]) and (not r['native_labels'][native_key]) for r in rows)
 fp=sum(r[det_key] and (not r['native_labels'][native_key]) for r in rows);fn=sum((not r[det_key]) and r['native_labels'][native_key] for r in rows)
 detection_eval[concept]={'annotated_unique_images':len(rows),'tp':tp,'tn':tn,'fp':fp,'fn':fn,'recall':tp/(tp+fn) if tp+fn else None,'note':'YOLO entity presence; not damage recognition'}
# Positive damage examples with no YOLO target entity prediction.
positive_candidates=[]
for r in model_rows:
 for claim,target,condition in [('building_damage','building','building.affected_or_greater'),('road_damage','road','road.damaged')]:
  if r['labels'].get(claim)==1 and not r['yolo_detection_labels'].get(target,0):
   pred=r['clip_conditions'].get(condition)
   positive_candidates.append({'image_id':r['image_id'],'claim':claim,'target_entity':target,'clip_condition':condition,
     'clip_proxy_positive':None if pred is None else pred['proxy_positive'],'clip_positive_similarity':None if pred is None else pred['positive'],
     'clip_negative_similarity':None if pred is None else pred['negative'],'yolo_detections':r['yolo_detections'],
     'source':r['source'],'local_match':r['local_match'],'local_path':r['local_path'],'remote_path':r['path_remote'],
     'group':r['group'],'native_labels':r['native_labels'],'image_labels':r['labels']})
# Candidate selection will be finalized after sorting by target-specific examples and local availability.
counts={'prepared_records':len(prepared),'prepared_source_counts':dict(collections.Counter(r['source'] for r in prepared)),
 'local_records':len(local),'local_source_counts':dict(collections.Counter(r['source'] for r in local)),
 'e_extracted_feature_images':len(features),'e_feature_source_counts':dict(collections.Counter(r['source'] for r in model_rows)),
 'e_extracted_groups':len({r['group'] for r in model_rows}),'e_image_ids_overlapping_local180':len(feature_ids&set(local_by)),
 'e_parameter_observations':len(params),'e_observation_source_counts':dict(source_obs),'observation_counts_by_source':obs_counts,
 'e_param_unique_image_ids':len({r['image_id'] for r in params}),'e_param_unique_groups':len({prepared_by[r['image_id']]['group'] for r in params}),
 'e_param_unique_parent_ids':len({prepared_by[r['image_id']]['parent_id'] for r in params}),
 'yolo_object_presence_comparison':detection_eval,'positive_label_zero_yolo_target_detection_candidates':positive_candidates,
 'prepared_manifest_sha256':hashlib.sha256(prepared_path.read_bytes()).hexdigest(),'local_manifest_sha256':hashlib.sha256(local_path.read_bytes()).hexdigest(),
 'e_status_sha256':hashlib.sha256((base/'results/cloud_annotation_pilot/20261025e/status.json').read_bytes()).hexdigest()}
out=pathlib.Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\ops\20261025T142100Z\actual_extraction_diagnostic\lineage_and_model_summary.json')
out.write_text(json.dumps(counts,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in counts.items() if k not in ('positive_label_zero_yolo_target_detection_candidates',)},indent=2))
print('candidate_count',len(positive_candidates))


