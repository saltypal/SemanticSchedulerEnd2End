import sys,json,time,hashlib,importlib.metadata,importlib.util
from pathlib import Path
ROOT=Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit')
END=Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerEnd2End')
BS=ROOT/'BetterScheduler'; DATA=BS/'results/local/20261025T082051Z/data/records.json'
MODEL=END/'models/priority_classifiers/clip'; OUT=Path(sys.argv[1])
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(END))
started=time.perf_counter();print('BEGIN real local CLIP relevance preflight',flush=True)
from BetterScheduler.ue_profiles import load_ue_profiles
from BetterScheduler.vision import FrozenVisionProvider
from BetterScheduler.pilot_parameters import PilotParameterExtractor,context_similarity_key
from BetterScheduler.contracts import MethodSpecification
def file_sha256(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda:handle.read(1024*1024),b""):h.update(block)
    return h.hexdigest()
from PIL import Image
import numpy as np
records=json.loads(DATA.read_text(encoding='utf-8'))
row=next((r for r in records if Path(r.get('image_path','')).is_file()),None)
if row is None:raise RuntimeError('no image path from existing local records.json is readable')
image_path=Path(row['image_path']); image_hash=file_sha256(image_path)
# Deliberately do not read or serialize any evaluator label fields.
print('Input image found; SHA256',image_hash,'bytes',image_path.stat().st_size,flush=True)
with Image.open(image_path) as src:image=src.convert('RGB')
missions,bindings=load_ue_profiles()
provider=FrozenVisionProvider('clip',str(MODEL),device='cpu',batch_size=1,local_files_only=True)
load_start=time.perf_counter();provider.load();load_seconds=time.perf_counter()-load_start
# One image encoder forward. Mission text forwards follow on the same frozen model.
base_evidence=provider.extract_batch([image],[missions[bindings[0].mission_id]])[0]
paragraphs=[m.paragraph for m in missions.values()]
text_features=provider._texts(paragraphs)
image_feature=np.asarray(base_evidence.embedding,dtype=np.float32)
cosines=np.asarray(text_features,dtype=np.float32)@image_feature
extractor=PilotParameterExtractor(specification=MethodSpecification(relevance='similarity'))
results=[]
for mission,vec,cos in zip(missions.values(),text_features,cosines):
    evidence=base_evidence
    evidence.similarities[context_similarity_key(mission)]=float(cos)
    value=extractor.extract_context_relevance(evidence,mission)
    tokenized=provider.processor.tokenizer(mission.paragraph,add_special_tokens=True,truncation=False,return_tensors=None)
    token_ids=tokenized['input_ids']; token_count=len(token_ids)
    ctx=int(provider.model.config.text_config.max_position_embeddings)
    if token_count>ctx:raise AssertionError(f'paragraph {mission.mission_id} exceeds CLIP context {ctx}: {token_count}')
    if not value.available or value.method!='operator_paragraph_cosine_v1':raise AssertionError('expected actual operator paragraph relevance method')
    score=float(value.value)
    if not np.isfinite(cos) or not np.isfinite(score) or abs(score-(float(cos)+1)/2)>1e-6:raise AssertionError('nonfinite or inconsistent score mapping')
    results.append({'mission_id':mission.mission_id,'paragraph':mission.paragraph,'paragraph_sha256':value.supporting['paragraph_sha256'],
      'full_paragraph_token_count':token_count,'context_limit':ctx,'fits_without_truncation':True,
      'raw_cosine':float(cos),'mapped_score_0_1':score,'available':value.available,'method':value.method,
      'is_probability':value.supporting.get('is_probability'),'text_source':value.supporting.get('text_source')})
by_mission={r['mission_id']:r for r in results}
ue_rows=[{'ue_id':b.ue_id,'mission_id':b.mission_id,'description':b.description,
          'paragraph_sha256':by_mission[b.mission_id]['paragraph_sha256'],
          'raw_cosine':by_mission[b.mission_id]['raw_cosine'],'mapped_score_0_1':by_mission[b.mission_id]['mapped_score_0_1'],
          'token_count':by_mission[b.mission_id]['full_paragraph_token_count'],
          'context_limit':by_mission[b.mission_id]['context_limit'],'method':by_mission[b.mission_id]['method']}
         for b in bindings]
weights=MODEL/'pytorch_model.bin'
report={'status':'passed','scope':'one actual local image forward on frozen CLIP CPU, five full mission paragraphs, six UE bindings; no labels read, no detector run',
 'data_manifest_path':str(DATA),'data_manifest_sha256':hashlib.sha256(DATA.read_bytes()).hexdigest(),
 'input_image_path':str(image_path),'input_image_sha256':image_hash,'input_image_bytes':image_path.stat().st_size,
 'model_id':'openai/clip-vit-base-patch32','model_path':str(MODEL),'model_revision':None,
 'model_weights_file':'pytorch_model.bin','model_weights_sha256':file_sha256(weights),'model_weights_bytes':weights.stat().st_size,
 'provider_provenance':provider.provenance,'one_image_encoder_forward':len(provider.timings)==1,
 'image_forward_timings':provider.timings,'model_load_seconds':load_seconds,
 'python':sys.version,'python_executable':sys.executable,'packages':{n:importlib.metadata.version(n) for n in ('torch','transformers','numpy','Pillow')},
 'detector':{'status':'unavailable','reason':'ultralytics not installed locally; no detector execution attempted','package_present':importlib.util.find_spec('ultralytics') is not None},
 'method':'operator_paragraph_cosine_v1','method_is_probability':False,
 'missions':results,'six_ue_bindings':ue_rows,'all_paragraphs_fit_77':all(r['fits_without_truncation'] and r['context_limit']==77 for r in results),
 'elapsed_seconds':time.perf_counter()-started}
OUT.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'status':report['status'],'image_sha256':image_hash,'model_weights_sha256':report['model_weights_sha256'],'one_image_encoder_forward':report['one_image_encoder_forward'],'methods':[r['method'] for r in results],'all_paragraphs_fit_77':report['all_paragraphs_fit_77'],'seconds':report['elapsed_seconds'],'cosines':[{k:r[k] for k in ('mission_id','raw_cosine','mapped_score_0_1','full_paragraph_token_count')} for r in results]},indent=2),flush=True)
provider.close()


