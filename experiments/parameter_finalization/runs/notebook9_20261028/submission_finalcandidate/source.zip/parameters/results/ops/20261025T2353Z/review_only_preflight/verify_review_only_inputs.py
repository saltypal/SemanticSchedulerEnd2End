import hashlib,json
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
base=Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler')
run=base/'results/ops/20261025T2256Z/semantic_validation_h3/monitor/retrieved/results/semantic_validation/20261026h3'
receipt=base/'results/ops/20261025T2256Z/semantic_validation_h3/retrieval_verification.json'
verified=json.loads(receipt.read_text(encoding='utf-8'))
required=['config.json','data/records.json','data/review_cohort.json','data/controls_evaluator_only.json','data/actual_evaluator_only.json','data/full_controls_evaluator_only.json','data/full_actual_evaluator_only.json','extraction/features.jsonl','extraction/producer.json','extraction/status.json']
paths={rel:{'present':(run/rel).is_file(),'bytes':(run/rel).stat().st_size if (run/rel).is_file() else None,'sha256':hashlib.sha256((run/rel).read_bytes()).hexdigest() if (run/rel).is_file() else None} for rel in required}
cohort=json.loads((run/'data/review_cohort.json').read_text())
controls=json.loads((run/'data/controls_evaluator_only.json').read_text())
actual=json.loads((run/'data/actual_evaluator_only.json').read_text())
records=json.loads((run/'data/records.json').read_text())
image_paths={r['image_id']:r['image_path'] for r in records}
selected_images={image_id:{'path':image_paths.get(image_id),'present':bool(image_paths.get(image_id) and Path(image_paths[image_id]).is_file())} for image_id in cohort['image_ids']}
selected_image_checks={image_id:{'path':str(run/'data/images'/f'{image_id}.jpg'),'present':(run/'data/images'/f'{image_id}.jpg').is_file(),'sha256':hashlib.sha256((run/'data/images'/f'{image_id}.jpg').read_bytes()).hexdigest() if (run/'data/images'/f'{image_id}.jpg').is_file() else None} for image_id in cohort['image_ids']}
result={'checked_utc':datetime.now(timezone.utc).isoformat(),'kaggle_account':'satyapaladugu','quota':{'gpu_used_hours':2.30,'gpu_remaining_hours':27.70,'gpu_total_hours':30.0,'refresh_utc':'2026-10-31T00:00:00Z'},'source_kernel':{'slug':'satyapaladugu/betterscheduler-semantic-validation-20261026h3','latest_accessible_version':1,'status':'COMPLETE','remote_output_files':182,'next_page':False,'file_inventory_receipt':'remote_output_file_inventory.json'},'same_source_inputs':{'selected_parent_images':cohort['parent_images'],'images_per_stratum':cohort['images_per_stratum'],'controls':len(controls),'actual_cases':len(actual),'planned_per_model':len(controls)+len(actual),'all_selected_images_present':all(x['present'] for x in selected_image_checks.values()),'required_local_artifacts':paths,'selected_image_hashes':selected_image_checks,'previous_run_global_checksums':f"{verified['global_checksum']['verified']}/{verified['global_checksum']['entries']}",'previous_run_checksums':f"{verified['run_checksum']['verified']}/{verified['run_checksum']['entries']}"},'expected_import_contract':{'metadata_field':'kernel_sources','source_ref':'satyapaladugu/betterscheduler-semantic-validation-20261026h3','review_only_worker':'BetterScheduler.semantic_validation_run review stage with model=qwen9b','must_skip':'panel materialization, visual feature extraction, Qwen4B, all 4B weights, and scheduler training','mount_path':'not verified in a new notebook; discover and assert mounted source path before copying/reading'},'limits':{'proposed_server_seconds':1800,'proposed_internal_seconds':1650,'two_t4_max_aggregate_gpu_hours':1.0,'launch_authorized_in_this_preflight':False},'active_duplicate_check':{'kernel_status_receipt':'kernel_statuses.json','all_checked_betterscheduler_kernels_terminal':True}}
Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\ops\20261025T2353Z\review_only_preflight\review_only_preflight.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ('same_source_inputs',)},indent=2))
print('required artifacts present:',sum(v['present'] for v in paths.values()),'/',len(paths))
print('selected images present:',sum(v['present'] for v in selected_image_checks.values()),'/',len(selected_image_checks))
print('selected control/actual:',len(controls),len(actual))
