import ast,hashlib,importlib,json,pathlib,sys,tempfile,zipfile
root=pathlib.Path('BetterScheduler/staging/20261025d').resolve();out=pathlib.Path(sys.argv[1]); meta=json.loads((root/'kernel-metadata.json').read_text());man=json.loads((root/'pilot_manifest.json').read_text());nb=json.loads((root/'notebook.ipynb').read_text());zpath=root/'source.zip'; files=[];errors=[]
assert meta['is_private'] is True and meta['enable_gpu'] is True and meta['machine_shape']=='NvidiaTeslaT4'
assert meta['id']=='satyapaladugu/betterscheduler-annotation-pilot-20261025d'
assert meta['kernel_sources']==['satyapaladugu/betterscheduler-prepare-20261025b']
assert man['server_seconds']==3600 and man['internal_seconds']==3000 and man['maximum_allocated_gpu_hours']==2
for i,cell in enumerate(nb['cells']):
 if cell['cell_type']=='code': compile(''.join(cell['source']),f'notebook-cell-{i}','exec');files.append({'kind':'cell','id':i,'compiled':True})
arc=json.loads(json.dumps(man['source_manifest']))
with zipfile.ZipFile(zpath) as archive:
 names=set(archive.namelist());
 for name,expected in arc['files'].items():
  if name not in names: errors.append({'missing':name});continue
  actual=hashlib.sha256(archive.read(name)).hexdigest()
  if actual!=expected:errors.append({'hash_mismatch':name,'actual':actual,'expected':expected})
  compile(archive.read(name),name,'exec');files.append({'kind':'source','path':name,'compiled':True,'hash_ok':actual==expected})
 if errors: raise RuntimeError(json.dumps(errors))
 with tempfile.TemporaryDirectory(prefix='better-20261025d-') as td:
  target=pathlib.Path(td)
  for name in names:
   p=pathlib.PurePosixPath(name)
   if p.is_absolute() or '..' in p.parts:raise ValueError(f'unsafe archive path: {name}')
  archive.extractall(target)
  sys.path.insert(0,str(target))
  imports=['BetterScheduler.annotation_pilot','BetterScheduler.annotation_review','BetterScheduler.pilot_parameters','BetterScheduler.pilot_producers','BetterScheduler.qwen_reviewer','BetterScheduler.cloud_notebook','BetterScheduler.contracts']
  for name in imports:importlib.import_module(name)
print(json.dumps({'metadata_private':meta['is_private'],'slug':meta['id'],'kernel_sources':meta['kernel_sources'],'notebook_code_cells':sum(c['cell_type']=='code' for c in nb['cells']),'compiled_members':len(files),'source_zip_bytes':zpath.stat().st_size,'source_archive_sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'pilot_limits':{'server_seconds':man['server_seconds'],'internal_seconds':man['internal_seconds'],'aggregate_gpu_hours':man['maximum_allocated_gpu_hours']},'isolated_imports':'passed','errors':errors},indent=2))
