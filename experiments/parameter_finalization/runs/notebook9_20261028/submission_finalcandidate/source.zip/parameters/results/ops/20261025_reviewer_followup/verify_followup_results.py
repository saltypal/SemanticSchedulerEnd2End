"""Independent saved-output checks; no generation, repair, or model selection."""
import argparse,json,hashlib
from pathlib import Path
from collections import Counter
from BetterScheduler.annotation_review import score_controls

parser=argparse.ArgumentParser();parser.add_argument('run');parser.add_argument('--output',required=True)
args=parser.parse_args();run=Path(args.run);out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
status=json.loads((run/'status.json').read_text());assert status['status']=='complete',status
summary=json.loads((run/'summary.json').read_text());assert len(summary)==6
diagnostic=json.loads((run/'data/diagnostic_evaluator_only.json').read_text())
fresh=json.loads((run/'data/fresh_evaluator_only.json').read_text())
spec=json.loads((run/'data/cohort_spec.json').read_text())
assert len(diagnostic)==6 and len(fresh)==24 and len(spec['excluded_groups'])==56
assert not {c['reference']['group'] for c in fresh}&set(spec['excluded_groups'])
all_reviews=[];checked=[];fresh_results={}
for name,saved in summary.items():
    cases=fresh if name.endswith('_fresh_image') else diagnostic
    reviews=[json.loads(line) for line in (run/name/'reviews.jsonl').read_text().splitlines()]
    assert len(reviews)==len(cases)
    metrics=score_controls(cases,reviews);assert metrics==saved['metrics'],name
    by_id={r['case_id']:r for r in reviews};joint=[]
    for case in cases:
        row=by_id[case['case_id']]
        joint.append(row['status']=='complete' and all(row['parsed'][k]==v for k,v in case['expected'].items()))
        if name.endswith('_diagnostic_text'):
            assert not row['image_inputs']
            if row['status']=='complete':assert row['assessment_kind']=='text_only_protocol_diagnostic'
        else:
            assert len(row['image_inputs'])==1
            if row['status']=='complete':
                assert row['assessment_kind']=='annotation_assisted_model_review'
                assert max(row['processed_image_pixels'])<=262144
        raw=Path(row['raw_response_ref']).name
        assert (run/name/'raw'/raw).is_file()
    assert sum(joint)==saved['joint_correct']
    result={'cell':name,'joint_correct':sum(joint),'cases':len(cases),'metrics':metrics,
            'invalid_reasons':dict(Counter(r.get('message') for r in reviews if r['status']!='complete')),
            'hit_token_limit_count':sum(bool(r.get('hit_token_limit')) for r in reviews),
            'joint_correct_by_arm':{arm:sum(ok for ok,c in zip(joint,cases) if c['control_arm']==arm)
                                    for arm in ('complete','incomplete','contradicted')}}
    checked.append(result);all_reviews.extend(reviews)
    if name.endswith('_fresh_image'):fresh_results[name]={c['case_id']:ok for c,ok in zip(cases,joint)}
assert len(all_reviews)==72
original=fresh_results['candidate_provenance_v2_fresh_image']
repaired=fresh_results['candidate_provenance_explicit_v4_fresh_image']
paired=Counter(('both_correct' if original[k] and repaired[k] else 'repair_only_correct' if repaired[k]
                else 'original_only_correct' if original[k] else 'both_wrong') for k in original)
report={'status':'verified','actual_reviews':len(all_reviews),'all_six_saved_metric_rows_recomputed_exactly':True,
        'fresh_groups':len({c['reference']['group'] for c in fresh}),'paired_joint_results':dict(paired),
        'cells':checked,'scope':'eight fresh duplicate/image groups; not event generalization or full-scene validation'}
(out/'verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
