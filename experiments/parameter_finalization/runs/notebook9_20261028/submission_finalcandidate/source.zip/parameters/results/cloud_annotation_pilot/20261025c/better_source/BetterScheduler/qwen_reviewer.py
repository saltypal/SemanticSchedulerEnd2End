"""Bounded annotation-assisted Qwen review,explicitly on GPU1."""
from pathlib import Path
import json
import time
from .annotation_review import reviewer_input,parse_review
from .contracts import digest
from .pilot_producers import file_sha256


class QwenAnnotationReviewer:
    def __init__(self,model_path,revision,device='cuda:1',max_new_tokens=192):
        if device!='cuda:1':raise ValueError('reviewer must explicitly own GPU1')
        self.model_path,self.revision,self.device=str(model_path),revision,device
        self.max_new_tokens=max_new_tokens;self.loaded=False

    def load(self):
        if self.loaded:return
        import torch
        from transformers import AutoProcessor,Qwen3VLForConditionalGeneration
        if torch.cuda.device_count()<2:raise RuntimeError('two assigned GPUs required')
        self.torch=torch;started=time.perf_counter()
        self.processor=AutoProcessor.from_pretrained(self.model_path,local_files_only=True,max_pixels=512*512)
        self.model=Qwen3VLForConditionalGeneration.from_pretrained(self.model_path,local_files_only=True,
            torch_dtype=torch.float16,attn_implementation='sdpa',device_map={'':self.device}).eval()
        devices=sorted({str(p.device) for p in self.model.parameters()})
        if devices!=[self.device]:raise RuntimeError('reviewer placement is not exclusively GPU1: '+str(devices))
        weights={p.name:file_sha256(p) for p in Path(self.model_path).glob('*.safetensors')}
        self.provenance={'model_id':'Qwen/Qwen3-VL-4B-Instruct','revision':self.revision,
            'weights_sha256':weights,'device':self.device,'dtype':'float16','attention':'sdpa',
            'max_image_pixels':512*512,'max_new_tokens':self.max_new_tokens,
            'do_sample':False,'load_seconds':time.perf_counter()-started,'parameter_devices':devices,
            'mode':'annotation_assisted_visible_json','not_independent_ground_truth':True}
        self.loaded=True

    def review(self,image_paths,candidate,reference,mission,rubric,history,case_id,raw_dir):
        self.load()
        from PIL import Image,ImageOps
        raw_dir=Path(raw_dir);raw_dir.mkdir(parents=True,exist_ok=True)
        payload=reviewer_input(candidate,reference,mission,rubric,history)
        content=[];images=[];receipts=[]
        # Current image is first;past image identifiers are logged in history.
        for path in image_paths:
            with Image.open(path) as image:picture=ImageOps.contain(image.convert('RGB'),(512,512))
            images.append(picture);content.append({'type':'image','image':picture})
            receipts.append({'sha256':file_sha256(path),'supplied_size':list(picture.size)})
        content.append({'type':'text','text':'Image1 is the current observation; subsequent images are declared past views.\n'+json.dumps(payload,allow_nan=False)})
        messages=[{'role':'user','content':content}]
        start=time.perf_counter();raw='';inputs=None
        try:
            inputs=self.processor.apply_chat_template(messages,tokenize=True,add_generation_prompt=True,
                        return_dict=True,return_tensors='pt').to(self.device)
            if 'pixel_values' not in inputs or inputs['pixel_values'].numel()==0:
                raise RuntimeError('vision pixels absent from reviewer input')
            self.torch.cuda.synchronize(1);self.torch.cuda.reset_peak_memory_stats(1)
            with self.torch.inference_mode():
                generated=self.model.generate(**inputs,max_new_tokens=self.max_new_tokens,do_sample=False)
            self.torch.cuda.synchronize(1)
            tokens=generated[0,inputs['input_ids'].shape[1]:]
            raw=self.processor.decode(tokens,skip_special_tokens=True).strip()
            raw_path=raw_dir/(case_id+'.txt');raw_path.write_text(raw,encoding='utf-8')
            parsed,recovered=parse_review(raw)
            return {'case_id':case_id,'status':'complete','parsed':parsed,'raw_response_ref':str(raw_path),
                    'parse_recovery_used':recovered,'wall_seconds':time.perf_counter()-start,
                    'generated_tokens':len(tokens),'input_tokens':int(inputs['input_ids'].shape[1]),
                    'pixel_tensor_shape':list(inputs['pixel_values'].shape),'image_inputs':receipts,
                    'prompt_sha256':digest(payload),'peak_gpu1_bytes':self.torch.cuda.max_memory_allocated(1),
                    'assessment_kind':'annotation_assisted_model_review','model_revision':self.revision}
        except Exception as error:
            path=raw_dir/(case_id+'.failure.json')
            path.write_text(json.dumps({'error':type(error).__name__,'message':str(error),'raw':raw},indent=2))
            return {'case_id':case_id,'status':'parse_failed' if raw else 'model_failed',
                    'error':type(error).__name__,'message':str(error),'raw_response_ref':str(path),
                    'wall_seconds':time.perf_counter()-start,'image_inputs':receipts}
        finally:
            del inputs

    def close(self):
        if hasattr(self,'model'):del self.model
        if hasattr(self,'processor'):del self.processor
        import gc
        gc.collect()
        if hasattr(self,'torch'):self.torch.cuda.empty_cache()
