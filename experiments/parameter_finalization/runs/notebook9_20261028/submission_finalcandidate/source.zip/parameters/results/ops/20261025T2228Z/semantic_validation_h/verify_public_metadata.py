import json,urllib.parse,urllib.request
from pathlib import Path
from huggingface_hub import HfApi
spec=json.loads(Path('BetterScheduler/config/semantic_validation_v1.json').read_text()); api=HfApi(); evidence={'model_metadata':[],'dataset_rows':{},'no_weight_download':True}
for key in ('qwen4b','qwen9b'):
 row=spec['models'][key]; info=api.model_info(row['model_id'],revision=row['revision'],files_metadata=False); files=[s.rfilename for s in info.siblings]
 evidence['model_metadata'].append({'key':key,'model_id':row['model_id'],'requested_revision':row['revision'],'resolved_revision':info.sha,'revision_match':info.sha==row['revision'],'transformers_pin':row['transformers'],'has_config_json':'config.json' in files,'jinja_templates':[f for f in files if f.endswith('.jinja')],'weights_downloaded':False,'weights_downloaded_note':'Only Hub model metadata endpoint queried; no snapshot/weight download invoked.'})
assert all(x['revision_match'] for x in evidence['model_metadata'])
assert any(f.endswith('.jinja') for x in evidence['model_metadata'] if x['key']=='qwen9b' for f in x['jinja_templates'])
assert not any(x['jinja_templates'] for x in evidence['model_metadata'] if x['key']=='qwen4b')
rev=spec['panel_records'][0]['dataset_revision']; info=api.dataset_info('MITLL/LADI-v2-dataset',revision=rev); assert info.sha==rev
offsets=[r['source_row'] for r in spec['panel_records']]; start=min(offsets); length=max(offsets)-start+1
query=urllib.parse.urlencode({'dataset':'MITLL/LADI-v2-dataset','config':'default','split':'test','offset':start,'length':length})
req=urllib.request.Request('https://datasets-server.huggingface.co/rows?'+query,headers={'User-Agent':'BetterScheduler-preflight'})
with urllib.request.urlopen(req,timeout=45) as response: payload=json.load(response)
byrow={entry['row_idx']:entry['row'] for entry in payload['rows']}
verified=[]
for r in spec['panel_records']:
 live=byrow[r['source_row']]; labels={k:v for k,v in live.items() if k!='image'}; src=live['image']['src']; parsed=urllib.parse.urlsplit(src)
 if labels!=r['native_labels']:raise AssertionError('native label drift at row '+str(r['source_row']))
 if parsed.hostname!='datasets-server.huggingface.co' or '/'+rev+'/' not in parsed.path:raise AssertionError('source image revision/host drift')
 verified.append({'row':r['source_row'],'stratum':r['stratum'],'labels_match':True,'asset_host':parsed.hostname,'asset_path_revision_match':True,'signed_query_present':bool(parsed.query)})
evidence['dataset_rows']={'dataset':'MITLL/LADI-v2-dataset','split':'test','revision':rev,'revision_match':True,'requested_rows':len(offsets),'available_rows_in_range':len(byrow),'labels_and_asset_revision_verified':len(verified),'asset_metadata':verified,'image_bytes_downloaded':0}
Path('BetterScheduler/results/ops/20261025T2228Z/semantic_validation_h/public_metadata_preflight.json').write_text(json.dumps(evidence,indent=2))
print(json.dumps(evidence,indent=2))
