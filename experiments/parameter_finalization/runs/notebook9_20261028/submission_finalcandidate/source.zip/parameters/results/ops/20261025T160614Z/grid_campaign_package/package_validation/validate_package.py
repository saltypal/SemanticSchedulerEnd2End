import json,ast,hashlib,zipfile,tempfile,sys,os
from pathlib import Path
stage=Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\staging\20261025f')
notebook=json.loads((stage/'notebook.ipynb').read_text(encoding='utf-8'))
meta=json.loads((stage/'kernel-metadata.json').read_text(encoding='utf-8'))
manifest=json.loads((stage/'pilot_manifest.json').read_text(encoding='utf-8'))
grid=json.loads((stage/'grid_manifest.json').read_text(encoding='utf-8'))
assert meta['id']=='satyapaladugu/betterscheduler-model-grid-20261025f' and meta['is_private'] and meta['enable_gpu'] and meta['machine_shape']=='NvidiaTeslaT4'
assert meta['kernel_sources']==['satyapaladugu/betterscheduler-prepare-20261025b']
assert manifest['slug']==meta['id'] and manifest['upstream']==meta['kernel_sources'][0]
assert manifest['server_seconds']==3600 and manifest['internal_seconds']==3000 and manifest['maximum_allocated_gpu_hours']==2
assert manifest['scope']=='YOLO12 CLIP8 Qwen8; no automatic winner or downstream training'
assert grid['source_manifest']['tag']=='20261025f' and grid['source_manifest']['scope']=='authorized remaining grids:YOLO12 CLIP8 Qwen8;no scheduler training'
assert len(grid['source_manifest']['files'])>40
code=[c for c in notebook['cells'] if c.get('cell_type')=='code']
assert len(code)==4, len(code)
for i,c in enumerate(code): compile(''.join(c['source']),f'notebook-cell-{i}','exec')
setup=''.join(code[0]['source']); tree=ast.parse(setup)
source_assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CELL_SOURCES' for t in n.targets))
embedded=ast.literal_eval(source_assignment.value)
assert len(embedded)==4, len(embedded)
for i,s in enumerate(embedded): compile(s,f'embedded-cell-source-{i}','exec')
zip_path=stage/'source.zip'; zhash=hashlib.sha256(zip_path.read_bytes()).hexdigest()
with zipfile.ZipFile(zip_path) as z:
    names=z.namelist()
    assert len(names)==len(set(names))
    expected=grid['source_manifest']['files']
    for name,digest in expected.items():
        archive_name=name
        assert archive_name in names, name
        assert hashlib.sha256(z.read(archive_name)).hexdigest()==digest, name
    td=Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\ops\20261025T160614Z\grid_campaign_package\package_validation\isolated')
    td.mkdir(parents=True,exist_ok=True);z.extractall(td)
# Heavy inference libraries are stubbed to make accidental model initialization fail during import-only checks.
stub=td.parent/'stubs';stub.mkdir(exist_ok=True)
(stub/'ultralytics.py').write_text("class YOLOWorld:\n def __init__(self,*a,**k): raise AssertionError('model init forbidden in import check')\n",encoding='utf-8')
(stub/'transformers.py').write_text("class AutoProcessor:\n @classmethod\n def from_pretrained(cls,*a,**k): raise AssertionError('model init forbidden in import check')\nclass Qwen3VLForConditionalGeneration: pass\n",encoding='utf-8')
sys.path.insert(0,str(stub));sys.path.insert(0,str(td))
import BetterScheduler.cloud_model_grid as cgm
import BetterScheduler.reviewer_grid as rg
assert Path(cgm.__file__).resolve().is_relative_to(td.resolve())
assert Path(rg.__file__).resolve().is_relative_to(td.resolve())
# Verify configured grid cardinalities and safety exclusions.
configs=json.loads((td/'BetterScheduler/config/approach_search_grid.json').read_text())
assert len(configs['stages']['detector']['configurations'])==12
assert len(configs['stages']['clip_alignment']['configurations'])==8
assert len(configs['stages']['reviewer_controls']['configurations'])==8
ex=json.loads((td/'BetterScheduler/config/grid_control_exclusions.json').read_text())
assert len(ex['groups'])==48
result={'status':'passed','private':meta['is_private'],'kernel_id':meta['id'],'accelerator':meta['machine_shape'],'upstream':meta['kernel_sources'][0],
'notebook_cells':len(notebook['cells']),'code_cells':len(code),'embedded_cell_sources':len(embedded),'embedded_cells_compiled':True,
'archive_files':len(names),'archive_sha256':zhash,'manifest_files_verified':len(expected),'isolated_imports':['BetterScheduler.cloud_model_grid','BetterScheduler.reviewer_grid'],
'inference_libraries_stubbed':True,'model_initialization_called':False,'config_counts':{'detector':12,'clip':8,'reviewer':8},'excluded_prior_groups':len(ex['groups']),
'caps':{'server_seconds':manifest['server_seconds'],'internal_seconds':manifest['internal_seconds'],'max_allocated_gpu_hours':manifest['maximum_allocated_gpu_hours']},'upstream_confirmed':meta['kernel_sources'][0]==manifest['upstream']}
out=Path(sys.argv[1]);out.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
