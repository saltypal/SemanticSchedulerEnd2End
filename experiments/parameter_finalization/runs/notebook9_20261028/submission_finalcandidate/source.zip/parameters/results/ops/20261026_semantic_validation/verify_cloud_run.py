"""Recompute saved semantic results; compare only identical attempted cases."""
import argparse,hashlib,json
from pathlib import Path
from collections import Counter
from BetterScheduler.semantic_panel import score_panel
from BetterScheduler.semantic_contract import audit_candidate

parser=argparse.ArgumentParser();parser.add_argument('run');parser.add_argument('--output',required=True)
args=parser.parse_args();root=Path(args.run);output=Path(args.output);output.mkdir(parents=True,exist_ok=True)
status=json.loads((root/'status.json').read_text())
report={'experiment_status':status,'model_results':{},'scope':'development pilot, two primary native building facts'}
cases=[]
for name in ('controls','actual'):
    path=root/'data'/(name+'_evaluator_only.json')
    if path.is_file():cases.extend(json.loads(path.read_text()))
for case in cases:
    computed=audit_candidate(case['candidate'],case['reference'])
    assert computed==case['audit'],case['case_id']
    assert case['expected']=={'parameters_consistent':computed['factual']['known_subset_consistent'],
                             'representation_sufficient':computed['factual']['all_required_verified']}
by_case={c['case_id']:c for c in cases};model_reviews={}
for model in ('qwen4b','qwen9b'):
    path=root/model/'reviews.jsonl';model_reviews[model]=[]
    if not path.is_file():continue
    rows=[json.loads(line) for line in path.read_text().splitlines()];model_reviews[model]=rows
    assert len({r['case_id'] for r in rows})==len(rows)
    assert set(r['case_id'] for r in rows)<=set(by_case)
    metrics={}
    for kind in ('controls','actual'):
        subset=[c for c in cases if (c['arm']=='actual_extractor')==(kind=='actual')]
        metrics[kind]=score_panel(subset,[r for r in rows if r['case_id'] in {c['case_id'] for c in subset}])
    saved_path=root/model/'metrics.json'
    saved_metrics_verified=False
    if saved_path.is_file():
        saved=json.loads(saved_path.read_text())
        assert metrics==saved,model
        saved_metrics_verified=True
    for row in rows:
        assert len(row['image_inputs'])==1
        assert row['image_inputs'][0]['sha256']==by_case[row['case_id']]['image_id']
        if row['status']=='complete':
            assert row['enable_thinking'] is False and row['thinking_disabled_verified']
            assert row['finite_preflight_passed'] is True
            assert max(row['processed_image_pixels'])<=262144
        raw=root/model/'raw'/Path(row['raw_response_ref']).name
        assert raw.is_file()
    provenance_path=root/model/'model.json'
    provenance_verified=False
    if provenance_path.is_file():
        provenance=json.loads(provenance_path.read_text())
        assert provenance['parameter_devices']==['cuda:1'] and provenance['enable_thinking'] is False
        if model=='qwen9b':assert provenance['linear4bit_modules']>0
        provenance_verified=True
    attempted_metrics={}
    for kind in ('controls','actual'):
        subset=[by_case[r['case_id']] for r in rows
                if (by_case[r['case_id']]['arm']=='actual_extractor')==(kind=='actual')]
        selected={c['case_id'] for c in subset}
        attempted_metrics[kind]=score_panel(subset,[r for r in rows if r['case_id'] in selected])
    report['model_results'][model]={'attempted':len(rows),'metrics':metrics,
        'saved_metrics_verified':saved_metrics_verified,'model_provenance_verified':provenance_verified,
        'metrics_scope':'stored full-planned execution-coverage scores; do not interpret unattempted cases as model answers',
        'attempted_case_metrics':attempted_metrics,
        'subset_scope':'descriptive only; incomplete subsets cannot qualify the planned control gate',
        'invalid_reasons':dict(Counter(r.get('message') for r in rows if r['status']!='complete')),
        'generated_tokens':sum(r.get('generated_tokens',0) for r in rows),
        'max_peak_gpu_bytes':max((r.get('peak_gpu1_bytes',0) for r in rows),default=0),
        'sum_case_wall_seconds':sum(r['wall_seconds'] for r in rows)}
common=set(r['case_id'] for r in model_reviews['qwen4b'])&set(r['case_id'] for r in model_reviews['qwen9b'])
report['paired_common_attempted']={}
report['common_case_ids']=sorted(common)
for kind in ('controls','actual'):
    selected={k for k in common if (by_case[k]['arm']=='actual_extractor')==(kind=='actual')}
    report['paired_common_attempted'][kind]={
        'case_ids':sorted(selected),'case_count':len(selected),
        'metrics':{model:score_panel([by_case[k] for k in sorted(selected)],
            [r for r in rows if r['case_id'] in selected]) for model,rows in model_reviews.items()} if selected else {},
        'scope':'same attempted cases, including invalid answers; descriptive when planned cohort incomplete'}
report['common_case_count']=len(common)
images=list((root/'data/images').glob('*.jpg'))
records_path=root/'data/records.json'
if records_path.is_file():
    records=json.loads(records_path.read_text())
    expected={r['image_id'] for r in records}
    assert {hashlib.sha256(p.read_bytes()).hexdigest() for p in images}==expected
    report['verified_images']=len(images);report['strata']=dict(Counter(r['stratum'] for r in records))
trace_path=root/'extraction/trace.json'
if trace_path.is_file():
    trace=json.loads(trace_path.read_text())
    forbidden={'native_labels','expected','audit','control_arm','stratum','evaluator_facts'}
    def check(value):
        if isinstance(value,dict):
            assert not set(value)&forbidden
            for item in value.values():check(item)
        elif isinstance(value,list):
            for item in value:check(item)
    for row in trace:check(row['bundle'])
    report['runtime_bundle_forbidden_label_keys_absent']=True
    report['extraction']=json.loads((root/'extraction/status.json').read_text())
(output/'verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
