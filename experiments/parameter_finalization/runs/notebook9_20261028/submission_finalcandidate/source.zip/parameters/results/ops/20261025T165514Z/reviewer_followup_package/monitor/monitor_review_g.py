import hashlib,json,os,re,sys,time
from datetime import datetime,timezone
from pathlib import Path
from kaggle.api.kaggle_api_extended import KaggleApi
RUN=Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\ops\20261025T165514Z\reviewer_followup_package\monitor')
SLUG='satyapaladugu/betterscheduler-reviewer-repair-20261025g'
MAX_SECONDS=1800;POLL_SECONDS=60;LOG_SECONDS=300
TERMINAL={'COMPLETE','ERROR','FAILED','CANCELLED','CANCELED','STOPPED','TIMED_OUT'}
def utc():return datetime.now(timezone.utc).isoformat()
def status_name(obj):return str(getattr(obj,'status','UNKNOWN')).split('.')[-1].upper()
def writejson(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2),encoding='utf-8')
def snap(api,seq):
 text=api.kernels_logs(SLUG);b=text.encode('utf-8',errors='replace');p=RUN/'logs'/f'kernel_log_{seq:03d}_{datetime.now(timezone.utc).strftime("%H%M%S")}.log';p.write_bytes(b)
 events=[x for x in text.splitlines() if re.search(r'(?i)(stage|review|model|GPU|cuda|COMPLETE|FAILED|error|progress|tokens|calls)',x)]
 return {'path':str(p.relative_to(RUN)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'line_count':len(text.splitlines()),'events':events[-80:]}
def retrieve(api):
 dest=RUN/'retrieved';dest.mkdir(parents=True,exist_ok=True)
 pattern=r'(?i)(^|/)(artifact_checksums\.json|status\.json|summary\.json|metrics\.json|cohort_spec\.json|diagnostic_evaluator_only\.json|fresh_evaluator_only\.json|hardware\.json|manifest\.json|config\.json|progress\.json|cell_status\.json|dependency_receipt\.json|processor_preflight\.json|executed\.ipynb|.*\.jsonl|.*\.log|.*\.txt|.*\.json)$'
 files,token=api.kernels_output(SLUG,str(dest),file_pattern=pattern,quiet=True,page_size=100)
 fetched=[]
 for raw in files:
  p=Path(raw)
  if p.is_file():fetched.append({'path':str(p.relative_to(dest)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 checkpath=dest/'artifact_checksums.json';checked=[];missing=[];mismatch=[];manifest_count=0
 if checkpath.is_file():
  checks=json.loads(checkpath.read_text(encoding='utf-8'));manifest_count=len(checks);base=dest/'results'/'reviewer_followup'/'20261025g'
  for rel,want in checks.items():
   p=base/rel
   if not p.is_file():missing.append(rel);continue
   got=hashlib.sha256(p.read_bytes()).hexdigest()
   if got==want:checked.append(rel)
   else:mismatch.append({'path':rel,'expected':want,'actual':got})
 else:missing.append('artifact_checksums.json')
 return {'destination':str(dest),'file_pattern':pattern,'downloaded_files':len(fetched),'files':fetched,'checksum_manifest_entries':manifest_count,'checksum_verified':len(checked),'missing':missing,'mismatches':mismatch,'manifest_base':str(dest/'results'/'reviewer_followup'/'20261025g'),'api_next_page_token':token}
def main():
 writejson(RUN/'pid.json',{'pid':os.getpid(),'started_utc':utc(),'kernel':SLUG,'max_monitor_seconds':MAX_SECONDS,'poll_seconds':POLL_SECONDS,'log_snapshot_seconds':LOG_SECONDS})
 api=KaggleApi();api.authenticate();start=time.monotonic();last=None;lastlog=0;seq=0;events=[];errors=0
 while time.monotonic()-start<MAX_SECONDS:
  try:
   r=api.kernels_status(SLUG);s=status_name(r);failure=getattr(r,'failure_message',None);errors=0
   if s!=last:
    e={'utc':utc(),'status':s,'failure_message':failure,'elapsed_seconds':round(time.monotonic()-start,1)};events.append(e);writejson(RUN/'status_events.json',events);print('STATUS',e,flush=True);last=s
   now=time.monotonic()
   if s=='RUNNING' and (not lastlog or now-lastlog>=LOG_SECONDS):
    seq+=1
    try:
     lr=snap(api,seq);writejson(RUN/f'log_snapshot_{seq:03d}.json',lr)
     if lr['events']:print('LOG_EVENTS',json.dumps(lr['events'][-15:]),flush=True)
    except Exception as exc:print('LOG_SNAPSHOT_ERROR',type(exc).__name__,str(exc)[:400],flush=True)
    lastlog=now
   if s in TERMINAL:
    result={'terminal':{'utc':utc(),'status':s,'failure_message':failure,'elapsed_seconds':round(time.monotonic()-start,1)},'status_events':events}
    try:seq+=1;result['final_log']=snap(api,seq)
    except Exception as exc:result['final_log_error']=f'{type(exc).__name__}: {str(exc)[:500]}'
    try:result['retrieval']=retrieve(api)
    except Exception as exc:result['retrieval_error']=f'{type(exc).__name__}: {str(exc)[:1000]}'
    writejson(RUN/'terminal_receipt.json',result);print('TERMINAL',json.dumps({'status':s,'files':result.get('retrieval',{}).get('downloaded_files'),'verified':result.get('retrieval',{}).get('checksum_verified'),'missing':len(result.get('retrieval',{}).get('missing',[])),'mismatch':len(result.get('retrieval',{}).get('mismatches',[])),'error':result.get('retrieval_error')}),flush=True);return 0 if s=='COMPLETE' else 2
  except Exception as exc:
   errors+=1;print('STATUS_ERROR',errors,type(exc).__name__,str(exc)[:400],flush=True)
   if errors>=3:writejson(RUN/'monitor_error.json',{'utc':utc(),'errors':errors,'message':str(exc)[:800],'status_events':events});return 3
  time.sleep(POLL_SECONDS)
 writejson(RUN/'monitor_timeout_receipt.json',{'utc':utc(),'terminal':False,'last_status':last,'elapsed_seconds':round(time.monotonic()-start,1),'status_events':events});print('MONITOR_BOUND_REACHED',last,flush=True);return 4
if __name__=='__main__':sys.exit(main())
