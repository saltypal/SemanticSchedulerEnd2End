import json,pathlib,hashlib
from kaggle import KaggleApi
from kagglesdk.kernels.types.kernels_api_service import ApiDownloadKernelOutputRequest
root=pathlib.Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\cloud_annotation_pilot\20261025e')
paths=['raw/reviewer/control-7-complete.failure.json','raw/reviewer/ue04-1-compact.failure.json','raw/reviewer/control-9-complete.failure.json']
api=KaggleApi();api.authenticate();out=[]
with api.build_kaggle_client() as client:
 for rel in paths:
  req=ApiDownloadKernelOutputRequest();req.owner_slug='satyapaladugu';req.kernel_slug='betterscheduler-annotation-pilot-20261025e';req.file_path='results/annotation_pilot/20261025e/'+rel
  try:
   r=client.kernels.kernels_api_client.download_kernel_output(req);data=r.content;item={'path':rel,'http':r.status_code,'bytes':len(data)}
   if r.status_code==200:
    target=root/'results/annotation_pilot/20261025e'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);item.update(local_path=str(target),sha256=hashlib.sha256(data).hexdigest())
    try:item['failure']=json.loads(data.decode('utf-8'))
    except Exception:pass
   out.append(item)
  except Exception as e:out.append({'path':rel,'exception':type(e).__name__,'message':str(e).split(' for url:')[0][:120]})
(root.parent.parent/'missing_raw_failure_fetch.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
