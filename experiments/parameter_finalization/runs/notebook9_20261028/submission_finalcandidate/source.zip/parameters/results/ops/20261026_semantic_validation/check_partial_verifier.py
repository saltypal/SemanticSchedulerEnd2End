"""Analysis-only regression: recover incrementally saved reviews without final files."""
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
BETTER = HERE.parents[2]
source = BETTER / 'results/ops/20261025T2238Z/semantic_validation_h2a/monitor/retrieved/results/semantic_validation/20261026h2a'
assert source.is_dir()
with tempfile.TemporaryDirectory(prefix='partial-review-', dir=HERE) as temporary:
    root = Path(temporary)
    run = root / 'run'
    shutil.copytree(source, run)
    for name in ('metrics.json', 'model.json'):
        path = run / 'qwen4b' / name
        path.rename(path.with_suffix('.withheld'))
    subprocess.run([sys.executable, str(HERE / 'verify_cloud_run.py'), str(run),
                    '--output', str(root / 'verification')], check=True,
                   stdout=subprocess.DEVNULL)
    report = json.loads((root / 'verification/verification.json').read_text())
    baseline = report['model_results']['qwen4b']
    assert baseline['attempted'] == 3
    assert not baseline['saved_metrics_verified']
    assert not baseline['model_provenance_verified']
    assert set(baseline['attempted_case_metrics']) == {'controls', 'actual'}
    assert report['common_case_count'] == 0
    assert all(arm['case_count'] == 0 for arm in report['paired_common_attempted'].values())
    receipt = {'status': 'passed', 'fixture': 'h2a copy with final metrics/provenance withheld',
               'recovered_reviews': baseline['attempted'], 'source_artifacts_modified': False,
               'arms_separate': True, 'no_paired_cases_invented': True}
    (HERE / 'partial_verifier_check.json').write_text(json.dumps(receipt, indent=2))
    print(json.dumps(receipt, indent=2))
