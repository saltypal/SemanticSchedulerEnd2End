import json,pathlib,collections
bs=pathlib.Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler')
prep=json.loads((bs/'results/ops/20261025T110200Z/annotation_pilot/records.json').read_text());pb={r['image_id']:r for r in prep}
e=bs/'results/cloud_annotation_pilot/20261025e/results/annotation_pilot/20261025e'
params=[json.loads(x) for x in (e/'parameters/parameters.jsonl').read_text().splitlines() if x]
reviews=[json.loads(x) for x in (e/'reviews/parameter_reviews.jsonl').read_text().splitlines() if x]
refs={r['observation_id']:r for r in [json.loads(x) for x in (e/'references/references.jsonl').read_text().splitlines() if x]}
features={r['image_id']:r['evidence'] for r in [json.loads(x) for x in (e/'features/evidence.jsonl').read_text().splitlines() if x]}
obs_by_id={p['observation_id']:p for p in params}
fact_map={'building.present':('native_labels','buildings_any'),'road.present':('native_labels','roads_any'),'building.affected_or_greater':('native_labels','buildings_affected_or_greater'),'road.damaged':('native_labels','roads_damage')}
result={'per_fact_positive_denominators':{},'detector_presence_on_positive_observation_cases':{},'unique_ladi_observations_and_images':{}}
ladi=[p for p in params if pb[p['image_id']]['source']=='ladi'];ids={r['image_id'] for r in ladi};groups={pb[i]['group'] for i in ids}
result['unique_ladi_observations_and_images']={'observation_rows':len(ladi),'unique_image_ids':len(ids),'unique_parent_ids':len({pb[i]['parent_id'] for i in ids}),'unique_groups':len(groups),'repeated_rows_beyond_unique_image':len(ladi)-len(ids)}
for fact,(container,key) in fact_map.items():
 vals=[]
 for p in ladi:
  r=pb[p['image_id']];v=(r.get(container,{}) if container in r else {}).get(key)
  if type(v) is bool: vals.append((p,r,v))
 pos=[x for x in vals if x[2] is True]
 unique_pos={x[0]['image_id'] for x in pos};unique_groups={x[1]['group'] for x in pos}
 result['per_fact_positive_denominators'][fact]={'labeled_observation_rows':len(vals),'positive_observation_rows':len(pos),'positive_unique_images':len(unique_pos),'positive_unique_groups':len(unique_groups),'observation_ids':[x[0]['observation_id'] for x in pos],'image_ids':sorted(unique_pos),'group_ids':sorted(unique_groups)}
 det_true=sum(bool((features.get(i,{}).get('detections') or [])) for i in unique_pos)
 if fact in ('building.present','building.affected_or_greater'):
  target='building';entity_key='buildings_any'
 else:target='road';entity_key='roads_any'
 target_detect_count=sum(any(d['label']==target for d in (features.get(i,{}).get('detections') or [])) for i in unique_pos)
 result['detector_presence_on_positive_observation_cases'][fact]={'positive_observation_rows':len(pos),'positive_unique_images':len(unique_pos),'positive_unique_groups':len(unique_groups),'images_with_any_yolo_detection':det_true,'images_with_target_entity_yolo_detection':target_detect_count,'images_missing_target_entity_detection':len(unique_pos)-target_detect_count}
# Count direct comparisons separately by structured report, preserving repeated-observation denominators.
for view in ('structured','compact'):
 per=collections.defaultdict(lambda:{'true_observation_rows':0,'unique_images':set(),'unique_groups':set(),'predicted_positive_observations':0,'false_negative_observations':0})
 for row in reviews:
  if row['view']!=view:continue
  p=obs_by_id[row['observation_id']];src=pb[p['image_id']]
  for cmp in row.get('direct_reference_metrics',{}).get('comparisons',[]):
   x=per[cmp['fact']];x['unique_images'].add(p['image_id']);x['unique_groups'].add(src['group'])
   if cmp['reference'] is True:
    x['true_observation_rows']+=1
    x['predicted_positive_observations']+=int(cmp['prediction'] is True)
    x['false_negative_observations']+=int(cmp['prediction'] is False)
 result.setdefault('direct_review_truth_denominators',{})[view]={f:{'positive_observation_rows':v['true_observation_rows'],'unique_images_contributing_comparisons':len(v['unique_images']),'unique_groups_contributing_comparisons':len(v['unique_groups']),'predicted_positive':v['predicted_positive_observations'],'false_negative':v['false_negative_observations']} for f,v in per.items()}
out=bs/'results/ops/20261025T142100Z/actual_extraction_diagnostic/presence_lineage.json';out.write_text(json.dumps(result,indent=2),encoding='utf-8')
summary={k:v for k,v in result.items() if k!='per_fact_positive_denominators'}
summary['per_fact_positive_denominators']={k:{x:y for x,y in v.items() if x not in ('observation_ids','image_ids','group_ids')} for k,v in result['per_fact_positive_denominators'].items()}
print(json.dumps(summary,indent=2))
