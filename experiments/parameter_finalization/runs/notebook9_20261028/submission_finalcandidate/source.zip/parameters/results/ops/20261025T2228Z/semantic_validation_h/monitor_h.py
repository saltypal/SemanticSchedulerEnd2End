import hashlib, json, os, re, sys, time
from datetime import datetime, timezone
from pathlib import Path
from kaggle.api.kaggle_api_extended import KaggleApi

RUN = Path(r"D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\ops\20261025T2228Z\semantic_validation_h\monitor")
SLUG = "satyapaladugu/betterscheduler-semantic-validation-20261026h"
MAX_SECONDS, POLL_SECONDS, LOG_SECONDS = 2400, 60, 300
TERMINAL = {"COMPLETE", "ERROR", "FAILED", "CANCELLED", "CANCELED", "STOPPED", "TIMED_OUT"}
PATTERN = r"(?i)(^|/)(artifact_checksums\.json|checksums\.json|status\.json|summary\.json|metrics\.json|hardware\.json|manifest\.json|config\.json|progress\.json|cell_status\.json|dependency_receipt\.json|processor_preflight\.json|executed\.ipynb|.*\.jsonl|.*\.log|.*\.txt|.*\.csv|.*\.png|.*\.jpg|.*\.json)$"


def utc():
    return datetime.now(timezone.utc).isoformat()


def status_name(obj):
    return str(getattr(obj, "status", "UNKNOWN")).split(".")[-1].upper()


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2), encoding="utf-8")


def snapshot(api, seq):
    text = api.kernels_logs(SLUG)
    data = text.encode("utf-8", errors="replace")
    path = RUN / "logs" / f"kernel_log_{seq:03d}_{datetime.now(timezone.utc):%H%M%S}.log"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    events = [line for line in text.splitlines() if re.search(r"(?i)(stage|review|model|GPU|cuda|COMPLETE|FAILED|error|progress|tokens|calls|extract)", line)]
    return {"path": str(path.relative_to(RUN)), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "line_count": len(text.splitlines()), "events": events[-100:]}


def verify(base, manifest_path, retrieved_root):
    result = {"manifest": str(manifest_path.relative_to(retrieved_root)), "entries": 0, "verified": 0, "missing": [], "mismatches": [], "base": str(base)}
    if not manifest_path.is_file():
        result["missing"].append(manifest_path.name)
        return result
    checks = json.loads(manifest_path.read_text(encoding="utf-8"))
    result["entries"] = len(checks)
    for relative, expected in checks.items():
        path = base / relative
        if not path.is_file():
            result["missing"].append(relative)
        else:
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            if actual == expected:
                result["verified"] += 1
            else:
                result["mismatches"].append({"path": relative, "expected": expected, "actual": actual})
    return result


def retrieve(api):
    dest = RUN / "retrieved"
    dest.mkdir(parents=True, exist_ok=True)
    files, token = api.kernels_output(SLUG, str(dest), file_pattern=PATTERN, quiet=True, page_size=100)
    saved = []
    for raw_path in files:
        path = Path(raw_path)
        if path.is_file():
            saved.append({"path": str(path.relative_to(dest)), "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    root = dest / "results" / "semantic_validation" / "20261026h"
    global_check = verify(root, dest / "artifact_checksums.json", dest)
    run_check = verify(root, root / "checksums.json", dest)
    return {"destination": str(dest), "file_pattern": PATTERN, "downloaded_files": len(saved), "files": saved, "global_checksum": global_check, "run_checksum": run_check, "manifest_base": str(root), "executed_notebook_retrieved": any(x["path"].endswith(".ipynb") for x in saved), "cell_logs_retrieved": sum(bool(re.search(r"cell_evidence[/\\]cell_\d+\.log$", x["path"])) for x in saved), "api_next_page_token": token}


def main():
    RUN.mkdir(parents=True, exist_ok=True)
    write_json(RUN / "pid.json", {"pid": os.getpid(), "started_utc": utc(), "kernel": SLUG, "max_monitor_seconds": MAX_SECONDS, "poll_seconds": POLL_SECONDS, "log_snapshot_seconds": LOG_SECONDS})
    api = KaggleApi()
    api.authenticate()
    start, last, last_log, seq, events, errors = time.monotonic(), None, 0, 0, [], 0
    while time.monotonic() - start < MAX_SECONDS:
        try:
            status = api.kernels_status(SLUG)
            current = status_name(status)
            failure = getattr(status, "failure_message", None)
            errors = 0
            if current != last:
                event = {"utc": utc(), "status": current, "failure_message": failure, "elapsed_seconds": round(time.monotonic() - start, 1)}
                events.append(event)
                write_json(RUN / "status_events.json", events)
                print("STATUS", json.dumps(event), flush=True)
                last = current
            now = time.monotonic()
            if current == "RUNNING" and (not last_log or now - last_log >= LOG_SECONDS):
                seq += 1
                try:
                    log = snapshot(api, seq)
                    write_json(RUN / f"log_snapshot_{seq:03d}.json", log)
                    if log["events"]:
                        print("LOG_EVENTS", json.dumps(log["events"][-15:]), flush=True)
                except Exception as exc:
                    print("LOG_SNAPSHOT_ERROR", type(exc).__name__, str(exc)[:400], flush=True)
                last_log = now
            if current in TERMINAL:
                result = {"terminal": {"utc": utc(), "status": current, "failure_message": failure, "elapsed_seconds": round(time.monotonic() - start, 1)}, "status_events": events}
                try:
                    seq += 1
                    result["final_log"] = snapshot(api, seq)
                except Exception as exc:
                    result["final_log_error"] = f"{type(exc).__name__}: {str(exc)[:500]}"
                try:
                    result["retrieval"] = retrieve(api)
                except Exception as exc:
                    result["retrieval_error"] = f"{type(exc).__name__}: {str(exc)[:1000]}"
                write_json(RUN / "terminal_receipt.json", result)
                summary = {"status": current, "files": result.get("retrieval", {}).get("downloaded_files"), "global_verified": result.get("retrieval", {}).get("global_checksum", {}).get("verified"), "run_verified": result.get("retrieval", {}).get("run_checksum", {}).get("verified"), "retrieval_error": result.get("retrieval_error")}
                print("TERMINAL", json.dumps(summary), flush=True)
                return 0 if current == "COMPLETE" else 2
        except Exception as exc:
            errors += 1
            print("STATUS_ERROR", errors, type(exc).__name__, str(exc)[:400], flush=True)
            if errors >= 3:
                write_json(RUN / "monitor_error.json", {"utc": utc(), "errors": errors, "message": str(exc)[:800], "status_events": events})
                return 3
        time.sleep(POLL_SECONDS)
    write_json(RUN / "monitor_timeout_receipt.json", {"utc": utc(), "terminal": False, "last_status": last, "elapsed_seconds": round(time.monotonic() - start, 1), "status_events": events})
    print("MONITOR_BOUND_REACHED", last, flush=True)
    return 4


if __name__ == "__main__":
    sys.exit(main())
