class AutoProcessor:
 @classmethod
 def from_pretrained(cls,*a,**k): raise AssertionError('model init forbidden in import check')
class Qwen3VLForConditionalGeneration: pass
