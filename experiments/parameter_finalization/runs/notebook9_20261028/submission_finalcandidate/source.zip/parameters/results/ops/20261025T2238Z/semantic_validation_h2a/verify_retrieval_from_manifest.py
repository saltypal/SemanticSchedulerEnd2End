import hashlib, json, re
from pathlib import Path

ops = Path(__file__).resolve().parent
repo = ops.parents[4]
stage = repo / "BetterScheduler" / "staging" / "20261026h2a"
retrieved = ops / "monitor" / "retrieved"
package = json.loads((stage / "pilot_manifest.json").read_text(encoding="utf-8"))
tag = package["source_manifest"]["tag"]
run_root = retrieved / "results" / "semantic_validation" / tag
artifact_root = retrieved


def check(manifest_path, base):
    result = {"manifest": str(manifest_path), "base": str(base), "entries": 0, "verified": 0, "missing": [], "mismatches": []}
    if not manifest_path.is_file():
        result["missing"].append(str(manifest_path))
        return result
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    result["entries"] = len(manifest)
    for relative, expected in manifest.items():
        path = base / relative
        if not path.is_file():
            result["missing"].append(relative)
            continue
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual == expected:
            result["verified"] += 1
        else:
            result["mismatches"].append({"path": relative, "expected": expected, "actual": actual})
    return result


global_check = check(artifact_root / "artifact_checksums.json", run_root)
run_check = check(run_root / "checksums.json", run_root)
images = sorted((run_root / "data" / "images").glob("*.jpg")) if (run_root / "data" / "images").is_dir() else []
image_hashes = [{"path": str(path.relative_to(run_root)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size} for path in images]
cell_evidence = retrieved / "cell_evidence"
receipt = {
    "tag_derived_from_staged_source_manifest": tag,
    "run_root_derived_from_tag": str(run_root),
    "global_checksum": global_check,
    "run_checksum": run_check,
    "executed_notebook_present": (cell_evidence / "executed.ipynb").is_file(),
    "cell_status_present": (cell_evidence / "cell_status.json").is_file(),
    "cell_logs": sorted(path.name for path in cell_evidence.glob("cell_*.log")) if cell_evidence.is_dir() else [],
    "image_count": len(images),
    "images": image_hashes,
    "no_duplicate_remote_download_performed": True,
}
(ops / "checksum_correction.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
print(json.dumps({"tag": tag, "global_verified": global_check["verified"], "global_entries": global_check["entries"], "global_missing": len(global_check["missing"]), "global_mismatches": len(global_check["mismatches"]), "run_verified": run_check["verified"], "run_entries": run_check["entries"], "run_missing": len(run_check["missing"]), "run_mismatches": len(run_check["mismatches"]), "images": len(images), "notebook": receipt["executed_notebook_present"]}, ensure_ascii=True))
