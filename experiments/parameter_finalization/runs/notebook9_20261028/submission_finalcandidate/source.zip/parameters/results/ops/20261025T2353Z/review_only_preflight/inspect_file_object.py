from kaggle.api.kaggle_api_extended import KaggleApi
api=KaggleApi();api.authenticate();resp=api.kernels_list_files('satyapaladugu/betterscheduler-semantic-validation-20261026h3',page_size=10); x=resp.files[0]
print(type(x).__name__)
print('attributes',[n for n in dir(x) if not n.startswith('_')])
if hasattr(x,'to_dict'):print('dictkeys',list(x.to_dict().keys()))
print('objectkeys',list(vars(x).keys()))
