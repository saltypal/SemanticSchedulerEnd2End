class YOLOWorld:
 def __init__(self,*a,**k): raise AssertionError('model init forbidden in import check')
