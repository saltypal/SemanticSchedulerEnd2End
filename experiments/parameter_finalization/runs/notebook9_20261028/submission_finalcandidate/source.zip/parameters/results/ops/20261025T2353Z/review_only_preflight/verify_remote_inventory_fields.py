import json,re
from pathlib import Path
ops=Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\ops\20261025T2353Z\review_only_preflight')
p=ops/'review_only_preflight.json'; r=json.loads(p.read_text(encoding='utf-8')); inv=json.loads((ops/'remote_output_file_inventory.json').read_text(encoding='utf-8'))
names=[x['name'] for x in inv['files']]
required=['config.json','records.json','review_cohort.json','controls_evaluator_only.json','actual_evaluator_only.json','features.jsonl','producer.json','trace.json','checksums.json']
r['source_kernel']['remote_required_basenames']={name:(name in names) for name in required}
r['source_kernel']['remote_panel_image_count']=sum(bool(re.fullmatch(r'[0-9a-f]{64}\.jpg',name)) for name in names)
r['source_kernel']['remote_required_names_all_present']=all(r['source_kernel']['remote_required_basenames'].values())
p.write_text(json.dumps(r,indent=2),encoding='utf-8')
print(json.dumps(r['source_kernel'],indent=2))
