import ast,base64,hashlib,json,zipfile
from pathlib import Path
import nbformat
stage=Path('BetterScheduler/staging/20261026h2a'); out=Path('BetterScheduler/results/ops/20261025T2238Z/semantic_validation_h2a')
meta=json.loads((stage/'kernel-metadata.json').read_text()); manifest=json.loads((stage/'pilot_manifest.json').read_text()); spec=json.loads(Path('BetterScheduler/config/semantic_validation_v1.json').read_text())
nb=nbformat.read(stage/'notebook.ipynb',as_version=4); code=[c.source for c in nb.cells if c.cell_type=='code']
for i,s in enumerate(code): compile(s,f'cell_{i}','exec')
assert len(code)==4 and len([c for c in nb.cells if c.cell_type=='markdown'])==1
assert meta['id']=='satyapaladugu/betterscheduler-semantic-validation-20261026h2a' and meta['is_private'] and meta['enable_gpu'] and meta['machine_shape']=='NvidiaTeslaT4' and meta['enable_internet'] and not meta['kernel_sources']
assert manifest['slug']==meta['id'] and manifest['server_seconds']==1600 and manifest['internal_seconds']==1450 and abs(manifest['maximum_allocated_gpu_hours']-1600/1800)<1e-9 and manifest['upstream'] is None
assert manifest['source_manifest']['tag']=='20261026h2a'
call=next(n for n in ast.walk(ast.parse(code[0])) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='b64decode')
embedded=base64.b64decode(ast.literal_eval(call.args[0])); zipbytes=(stage/'source.zip').read_bytes(); assert embedded==zipbytes
with zipfile.ZipFile(stage/'source.zip') as z:
    names=set(z.namelist()); zmanifest=json.loads(z.read('SOURCE_MANIFEST.json')); expected=manifest['source_manifest']['files']
    assert zmanifest['files']==expected and set(expected)<=names
    mismatch=[]; missing=[]; intentional=[]; hashes={}
    for name,digest in expected.items():
        data=z.read(name); assert hashlib.sha256(data).hexdigest()==digest, name; hashes[name]=digest
        live=Path(name)
        if not live.is_file():missing.append(name)
        elif hashlib.sha256(live.read_bytes()).hexdigest()!=digest:
            if name in {'INFRA/__init__.py','INFRA/learning/__init__.py','Scheduler/__init__.py'}:intentional.append(name)
            else:mismatch.append(name)
    sources={name:z.read(name).decode('utf-8') for name in ('BetterScheduler/semantic_validation_driver.py','BetterScheduler/qwen_reviewer.py','BetterScheduler/qwen35_reviewer.py','BetterScheduler/semantic_validation_run.py')}
assert not mismatch, mismatch
assert not missing, missing
assert set(intentional)=={'INFRA/__init__.py','INFRA/learning/__init__.py','Scheduler/__init__.py'}
assert "'/kaggle/temp/qwen35_env'" in sources['BetterScheduler/semantic_validation_driver.py']
assert 'transformers==5.3.0' in sources['BetterScheduler/semantic_validation_driver.py']
assert 'enable_thinking=False' in sources['BetterScheduler/qwen_reviewer.py']
assert 'Qwen3_5ForConditionalGeneration' in sources['BetterScheduler/qwen35_reviewer.py']
assert 'maximum_generation_seconds=60' in sources['BetterScheduler/semantic_validation_run.py']
assert 'not an empty directory' in sources['BetterScheduler/semantic_validation_run.py']
assert 'output.mkdir(parents=True,exist_ok=True)' in sources['BetterScheduler/semantic_validation_run.py']
assert 'server_seconds=1600' in code[2]
assert 'ACTUAL saved artifact availability' in code[3]
assert 'Saved raw parameter JSON' not in code[3]
records=spec['panel_records']; strata={s:sum(r['stratum']==s for r in records) for s in ('absent','present_unaffected','affected')}
assert len(records)==12 and strata=={'absent':4,'present_unaffected':4,'affected':4}
assert all(r['source']=='ladi' and r['source_split']=='test' and r['dataset_revision']=='5f2dbfe8c466d32edafd1bab847ec5252309acdb' and r['role']=='development_pilot' for r in records)
assert spec['review_settings']['enable_thinking'] is False and spec['review_settings']['max_new_tokens']==192
assert spec['models']['qwen4b']['transformers']=='4.57.6' and spec['models']['qwen9b']['transformers']=='5.3.0'
assert spec['limits']['server_seconds']==1800 and spec['limits']['internal_seconds']==1450 and spec['limits']['maximum_aggregate_gpu_hours']==1
assert 'HF_HOME' in code[0] and not meta['kernel_sources'] and not manifest['upstream']
receipt={'status':'passed','archive_sha256':hashlib.sha256(zipbytes).hexdigest(),'archive_bytes':len(zipbytes),'source_manifest_entries':len(expected),'embedded_archive_exact_match':True,'live_source_mismatches':mismatch,'intentional_namespace_stub_differences':intentional,'notebook_cells':{'code':len(code),'markdown':1,'all_compile':True},'private_t4_gpu_internet':True,'upstream_sources':[],'server_seconds':1600,'internal_seconds':1450,'aggregate_gpu_hours_cap':1600/1800,'panel_records':len(records),'strata':strata,'test_source_revision':records[0]['dataset_revision'],'thinking_off':True,'model_transformers':{k:v['transformers'] for k,v in spec['models'].items()},'qwen35_env':'/kaggle/temp/qwen35_env','server_cap_declared_in_notebook_driver':True,'model_weights_downloaded_locally':False,'source_hashes':hashes}
(out/'package_validation.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({k:v for k,v in receipt.items() if k!='source_hashes'},indent=2))
(out/'source_hashes.json').write_text(json.dumps({'commit':manifest['source_manifest']['commit'],'hashes':hashes},indent=2))



