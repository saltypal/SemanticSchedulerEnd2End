import json,pathlib,hashlib
from kaggle import KaggleApi
from kagglesdk.kernels.types.kernels_api_service import ApiDownloadKernelOutputRequest
root=pathlib.Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\cloud_annotation_pilot\20261025e\results\annotation_pilot\20261025e')
paths=['config.json','manifest.json','hardware.json','data/control_cases_evaluator_only.json','data/control_exclusions.json','data/development_exposure.json','references/references.jsonl','parameters/representations.jsonl','parameters/parameters.jsonl','parameters/sequence_trace.jsonl','reviews/control_reviews.jsonl','reviews/parameter_reviews.jsonl','features/evidence.jsonl']
api=KaggleApi();api.authenticate();receipts=[]
with api.build_kaggle_client() as client:
 for rel in paths:
  req=ApiDownloadKernelOutputRequest();req.owner_slug='satyapaladugu';req.kernel_slug='betterscheduler-annotation-pilot-20261025e';req.file_path='results/annotation_pilot/20261025e/'+rel
  try:
   response=client.kernels.kernels_api_client.download_kernel_output(req);data=response.content
   item={'path':rel,'http':response.status_code,'bytes':len(data)}
   if response.status_code==200:
    target=root/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);item.update(local_path=str(target),sha256=hashlib.sha256(data).hexdigest())
   receipts.append(item)
  except Exception as e:receipts.append({'path':rel,'exception':type(e).__name__,'message':str(e).split(' for url:')[0][:120]})
(root.parent.parent/'retrieval_receipts_additional.json').write_text(json.dumps(receipts,indent=2),encoding='utf-8')
print(json.dumps(receipts,indent=2))
