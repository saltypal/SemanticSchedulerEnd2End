import hashlib,json,pathlib,sys
from kaggle import KaggleApi
from kagglesdk.kernels.types.kernels_api_service import ApiDownloadKernelOutputRequest
root=pathlib.Path(sys.argv[1]);files={
 'manifest.json':'results/prepare/20261025b/manifest.json',
 'progress.json':'results/prepare/20261025b/progress.json',
 'medic_sampling.json':'results/prepare/20261025b/data/medic/sampling.json',
 'medic_progress.json':'results/prepare/20261025b/data/medic/progress.json',
 'medic_preflight.json':'results/prepare/20261025b/data/medic/annotation_preflight.json',
 'ladi_upstream.json':'results/prepare/20261025b/data/ladi/upstream.json'}
a=KaggleApi();a.authenticate();rows=[]
with a.build_kaggle_client() as c:
 for name,path in files.items():
  q=ApiDownloadKernelOutputRequest();q.owner_slug='satyapaladugu';q.kernel_slug='betterscheduler-prepare-20261025b';q.file_path=path
  r=c.kernels.kernels_api_client.download_kernel_output(q)
  row={'name':name,'remote_path':path,'status':r.status_code}
  if r.status_code==200:
   data=r.content;(root/name).write_bytes(data);row.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
  else:row['error']=r.text[:300]
  rows.append(row)
(root/'additional_receipts.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
