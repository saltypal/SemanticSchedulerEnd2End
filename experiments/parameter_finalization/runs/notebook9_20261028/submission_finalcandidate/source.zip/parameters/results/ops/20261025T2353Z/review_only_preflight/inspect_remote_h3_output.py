import json
from datetime import datetime,timezone
from pathlib import Path
from kaggle.api.kaggle_api_extended import KaggleApi
api=KaggleApi();api.authenticate();slug='satyapaladugu/betterscheduler-semantic-validation-20261026h3';resp=api.kernels_list_files(slug,page_size=200)
files=[{'name':x.name,'bytes':x.size,'creation_date':str(x.creation_date)} for x in (resp.files or [])]
result={'checked_utc':datetime.now(timezone.utc).isoformat(),'kernel':slug,'status':'COMPLETE','kernel_version':1,'file_count':len(files),'next_page_token_present':bool(getattr(resp,'next_page_token',None)),'files':files,'contains_signed_urls':False}
Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\ops\20261025T2353Z\review_only_preflight\remote_output_file_inventory.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
print('KEY_OUTPUT_FILES')
for f in files:
 n=f['name'].lower()
 if any(x in n for x in ('records.json','evaluator_only','review_cohort','features.jsonl','config.json','image.jpg','checksums.json','status.json')):print(f['name'],f['bytes'])
