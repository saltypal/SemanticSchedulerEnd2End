"""Recompute archived f-control metrics and expose selection trade-offs."""
import hashlib,json
from pathlib import Path
from collections import Counter
from BetterScheduler.annotation_review import score_controls

ROOT=Path(__file__).resolve().parents[3]
SOURCE=ROOT/'results/ops/20261025T160614Z/grid_campaign_package/monitor/retrieved/results/model_grid/20261025f/reviewer'
OUTPUT=Path(__file__).resolve().parent
cases=json.loads((SOURCE/'cases_evaluator_only.json').read_text())
progress=json.loads((SOURCE/'progress.json').read_text())
summaries=[]
for item in progress:
    settings=item['settings']
    # Exported JSON uses canonical settings for identity, as does the runner.
    identity=hashlib.sha256(json.dumps(settings,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()[:16]
    reviews=[json.loads(line) for line in (SOURCE/(identity+'.jsonl')).read_text().splitlines()]
    recomputed=score_controls(cases,reviews)
    assert recomputed==item['metrics'],identity
    by_id={r['case_id']:r for r in reviews}
    failures=[]
    for case in cases:
        review=by_id[case['case_id']]
        correct=review['status']=='complete' and all(review['parsed'][k]==v for k,v in case['expected'].items())
        if not correct:
            failures.append({'case_id':case['case_id'],'arm':case['control_arm'],
                'building_present':case['reference']['facts']['building.present'],
                'affected':case['reference']['facts']['building.affected_or_greater'],
                'status':review['status'],'reason':review.get('parsed',{}).get('reason',review.get('message'))})
    failed_checks=[]
    if recomputed['valid_fraction']<.95:failed_checks.append('valid_fraction')
    if recomputed['omission_rejection_fraction']<.75:failed_checks.append('omission_rejection')
    for name,endpoint in recomputed['endpoints'].items():
        if endpoint['balanced_accuracy']<.8:failed_checks.append(name+'_balanced_accuracy')
        if min(endpoint['class_correct_fraction_including_invalid'].values())<.75:
            failed_checks.append(name+'_minimum_class_correct')
    summaries.append({'id':identity,'settings':settings,'metrics':recomputed,
        'joint_correct':len(cases)-len(failures),'failed_checks':failed_checks,'failures':failures,
        'invalid_reasons':dict(Counter(r.get('message') for r in reviews if r['status']!='complete')),
        'sum_case_wall_seconds':sum(r['wall_seconds'] for r in reviews)})
assert len(summaries)==8
(OUTPUT/'f_recomputed_metrics.json').write_text(json.dumps({'scope':'development paired eight-group controls',
    'all_eight_saved_metric_rows_recomputed_exactly':True,'configurations':summaries},indent=2))
print(json.dumps([{'id':r['id'],'joint_correct':r['joint_correct'],'failed_checks':r['failed_checks']} for r in summaries],indent=2))
