import hashlib, json, os, re, sys
from pathlib import Path
from kaggle.api.kaggle_api_extended import KaggleApi

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
os.environ["PYTHONUTF8"] = "1"
run = Path(r"D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\ops\20261025T2228Z\semantic_validation_h")
dest = run / "monitor" / "retrieved"
slug = "satyapaladugu/betterscheduler-semantic-validation-20261026h"
pattern = r"(?i)(^|/)(artifact_checksums\.json|checksums\.json|status\.json|summary\.json|metrics\.json|hardware\.json|manifest\.json|config\.json|progress\.json|cell_status\.json|dependency_receipt\.json|processor_preflight\.json|executed\.ipynb|.*\.jsonl|.*\.log|.*\.txt|.*\.csv|.*\.png|.*\.jpg|.*\.json)$"


def verify(base, manifest_path):
    result = {"manifest": str(manifest_path), "entries": 0, "verified": 0, "missing": [], "mismatches": []}
    if not manifest_path.is_file():
        result["missing"].append(manifest_path.name)
        return result
    checks = json.loads(manifest_path.read_text(encoding="utf-8"))
    result["entries"] = len(checks)
    for rel, expected in checks.items():
        path = base / rel
        if not path.is_file():
            result["missing"].append(rel)
            continue
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual == expected:
            result["verified"] += 1
        else:
            result["mismatches"].append({"path": rel, "expected": expected, "actual": actual})
    return result


dest.mkdir(parents=True, exist_ok=True)
api = KaggleApi()
api.authenticate()
files, token = api.kernels_output(slug, str(dest), file_pattern=pattern, quiet=True, page_size=100)
saved = []
for raw in files:
    path = Path(raw)
    if path.is_file():
        saved.append({"path": str(path.relative_to(dest)), "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
root = dest / "results" / "semantic_validation" / "20261026h"
receipt = {
    "attempt": 2,
    "reason": "single bounded retrieval correction after monitor attempt failed with Windows charmap UnicodeEncodeError; no notebook rerun",
    "kernel": slug,
    "retrieved_files": len(saved),
    "files": saved,
    "manifest_base": str(root),
    "global_checksum": verify(root, dest / "artifact_checksums.json"),
    "run_checksum": verify(root, root / "checksums.json"),
    "executed_notebook_retrieved": any(x["path"].endswith(".ipynb") for x in saved),
    "cell_logs_retrieved": sum(bool(re.search(r"cell_evidence[/\\]cell_\d+\.log$", x["path"])) for x in saved),
    "api_next_page_token": token,
}
(run / "retrieval_attempt_2.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
print(json.dumps({"retrieved_files": receipt["retrieved_files"], "global_verified": receipt["global_checksum"]["verified"], "global_missing": len(receipt["global_checksum"]["missing"]), "run_verified": receipt["run_checksum"]["verified"], "run_missing": len(receipt["run_checksum"]["missing"]), "notebook": receipt["executed_notebook_retrieved"], "cell_logs": receipt["cell_logs_retrieved"], "next_page_token": token}, ensure_ascii=True))
