import hashlib,json,os,re,sys,time
from datetime import datetime,timezone
from pathlib import Path
from kaggle.api.kaggle_api_extended import KaggleApi
ROOT=Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler')
RUN=ROOT/'results/ops/20261025T160614Z/grid_campaign_package/monitor'
SLUG='satyapaladugu/betterscheduler-model-grid-20261025f'
MAX_SECONDS=4500
POLL_SECONDS=60
LOG_SECONDS=300
terminal={'COMPLETE','ERROR','FAILED','CANCELLED','CANCELED','STOPPED','TIMED_OUT'}
def utc(): return datetime.now(timezone.utc).isoformat()
def response_status(value): return str(getattr(value,'status','UNKNOWN')).split('.')[-1].upper()
def save_json(path,obj): path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2),encoding='utf-8')
def snapshot_logs(api,seq):
    text=api.kernels_logs(SLUG)
    raw=text.encode('utf-8',errors='replace')
    name=f'kernel_log_{seq:03d}_{datetime.now(timezone.utc).strftime("%H%M%S")}.log'
    path=RUN/'logs'/name;path.write_bytes(raw)
    selected=[line for line in text.splitlines() if re.search(r'(?i)(stage|YOLO size|CLIP|reviewer config|parity|COMPLETE|FAILED|error|progress|GPU|cuda)',line)]
    return {'path':str(path.relative_to(RUN)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'lines':len(text.splitlines()),'selected_events':selected[-80:]}
def retrieve_outputs(api):
    dest=RUN/'retrieved';dest.mkdir(parents=True,exist_ok=True)
    pattern=r'(?i)(^|/)(artifact_checksums\.json|status\.json|stage_outcomes\.json|manifest\.json|config\.json|hardware\.json|progress\.json|cell_status\.json|executed\.ipynb|.*\.jsonl|.*\.log|.*\.txt|.*\.json)$'
    files,token=api.kernels_output(SLUG,str(dest),file_pattern=pattern,quiet=True,page_size=100)
    fetched=[]
    for f in files:
        p=Path(f)
        if p.is_file(): fetched.append({'path':str(p.relative_to(dest)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    checksum_path=dest/'artifact_checksums.json'
    checked=[];missing=[];mismatch=[];unretrieved=[]
    if checksum_path.is_file():
        checks=json.loads(checksum_path.read_text(encoding='utf-8'))
        for rel,expected in checks.items():
            local=dest/rel
            if not local.is_file():
                # Model weights and image inputs are intentionally not downloaded by this JSON/text-only filter.
                unretrieved.append(rel);continue
            actual=hashlib.sha256(local.read_bytes()).hexdigest()
            if actual==expected:checked.append(rel)
            else:mismatch.append({'path':rel,'expected':expected,'actual':actual})
    else:missing.append('artifact_checksums.json')
    return {'destination':str(dest),'downloaded_count':len(fetched),'downloaded':fetched,'checksum_manifest_present':checksum_path.is_file(),'checksum_verified_count':len(checked),'checksum_mismatches':mismatch,'intentionally_unretrieved_or_missing_count':len(unretrieved),'intentionally_unretrieved_sample':unretrieved[:30],'missing_files':missing,'api_next_page_token':token}
def main():
    pid=os.getpid();save_json(RUN/'pid.json',{'pid':pid,'started_utc':utc(),'slug':SLUG,'max_monitor_seconds':MAX_SECONDS,'poll_seconds':POLL_SECONDS,'log_snapshot_seconds':LOG_SECONDS})
    api=KaggleApi();api.authenticate()
    start=time.monotonic();last_status=None;last_log=0;log_seq=0;errors=0;events=[];terminal_result=None
    while time.monotonic()-start<MAX_SECONDS:
        try:
            response=api.kernels_status(SLUG);status=response_status(response);failure=getattr(response,'failure_message',None)
            errors=0
            if status!=last_status:
                event={'utc':utc(),'status':status,'failure_message':failure,'elapsed_seconds':round(time.monotonic()-start,1)}
                events.append(event);save_json(RUN/'status_events.json',events);print('STATUS',event,flush=True);last_status=status
            now=time.monotonic()
            if status=='RUNNING' and (not last_log or now-last_log>=LOG_SECONDS):
                log_seq+=1
                try:
                    receipt=snapshot_logs(api,log_seq);save_json(RUN/f'log_snapshot_{log_seq:03d}.json',receipt)
                    if receipt['selected_events']: print('LOG_EVENTS',json.dumps(receipt['selected_events'][-12:]),flush=True)
                    last_log=now
                except Exception as exc:
                    print('LOG_SNAPSHOT_ERROR',type(exc).__name__,str(exc)[:400],flush=True)
                    last_log=now
            if status in terminal:
                receipt={'utc':utc(),'status':status,'failure_message':failure,'elapsed_seconds':round(time.monotonic()-start,1)}
                terminal_result={'terminal':receipt}
                try:
                    log_seq+=1;terminal_result['final_log']=snapshot_logs(api,log_seq)
                except Exception as exc:terminal_result['final_log_error']=f'{type(exc).__name__}: {str(exc)[:400]}'
                try:terminal_result['retrieval']=retrieve_outputs(api)
                except Exception as exc:terminal_result['retrieval_error']=f'{type(exc).__name__}: {str(exc)[:500]}'
                terminal_result['status_events']=events;save_json(RUN/'terminal_receipt.json',terminal_result)
                print('TERMINAL',json.dumps({'status':status,'retrieved':terminal_result.get('retrieval',{}).get('downloaded_count'),'verified':terminal_result.get('retrieval',{}).get('checksum_verified_count'),'retrieval_error':terminal_result.get('retrieval_error')}),flush=True)
                return 0 if status=='COMPLETE' else 2
        except Exception as exc:
            errors+=1;print('STATUS_ERROR',errors,type(exc).__name__,str(exc)[:400],flush=True)
            if errors>=3:
                save_json(RUN/'monitor_error.json',{'utc':utc(),'consecutive_errors':errors,'error':type(exc).__name__,'message':str(exc)[:1000],'status_events':events})
                return 3
        time.sleep(POLL_SECONDS)
    receipt={'utc':utc(),'status':last_status,'terminal':False,'elapsed_seconds':round(time.monotonic()-start,1),'status_events':events}
    save_json(RUN/'monitor_timeout_receipt.json',receipt);print('MONITOR_BOUND_REACHED',json.dumps(receipt),flush=True);return 4
if __name__=='__main__':sys.exit(main())
