import ast,base64,hashlib,json,sys,zipfile
from pathlib import Path
root=Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit')
stage=root/'BetterScheduler/staging/20261025g'; nb=json.loads((stage/'notebook.ipynb').read_text(encoding='utf-8')); meta=json.loads((stage/'kernel-metadata.json').read_text()); manifest=json.loads((stage/'pilot_manifest.json').read_text()); spec=json.loads((root/'BetterScheduler/config/reviewer_followup_cohort.json').read_text(encoding='utf-8-sig'))
assert meta['id']=='satyapaladugu/betterscheduler-reviewer-repair-20261025g' and meta['is_private'] and meta['enable_gpu'] and meta['machine_shape']=='NvidiaTeslaT4'
assert meta['kernel_sources']==['satyapaladugu/betterscheduler-prepare-20261025b'] and manifest['upstream']==meta['kernel_sources'][0]
assert manifest['server_seconds']==1200 and manifest['internal_seconds']==900 and abs(manifest['maximum_allocated_gpu_hours']-2/3)<1e-12 and manifest['max_review_calls']==72
assert manifest['stage']=='paired_reviewer_repair' and manifest['source_manifest']['scope']=='paired reviewer repair:72calls;no extraction/training'
assert spec['max_review_calls']==72 and spec['fresh_control_parents']==8 and len(spec['diagnostic_cases'])==6 and len(spec['excluded_groups'])==56
assert len({c['reference']['group'] for c in spec['diagnostic_cases']})==2
assert {c['reference']['group'] for c in spec['diagnostic_cases']}<=set(spec['excluded_groups'])
code=[c for c in nb['cells'] if c.get('cell_type')=='code'];assert len(code)==4
for i,c in enumerate(code):compile(''.join(c['source']),f'notebook-cell-{i}','exec')
astree=ast.parse(''.join(code[0]['source']));ass=next(n for n in astree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CELL_SOURCES' for t in n.targets));embedded=ast.literal_eval(ass.value);assert len(embedded)==4
for i,s in enumerate(embedded):compile(s,f'embedded-source-{i}','exec')
zip_path=stage/'source.zip';zip_sha=hashlib.sha256(zip_path.read_bytes()).hexdigest()
# Embedded base64 ZIP must be byte-identical to staged archive.
call=next(n for n in ast.walk(astree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='b64decode')
embedded_zip=base64.b64decode(ast.literal_eval(call.args[0]));assert hashlib.sha256(embedded_zip).hexdigest()==zip_sha
srcmanifest=manifest['source_manifest']['files'];changed=[];missing=[]
with zipfile.ZipFile(zip_path) as z:
    names=z.namelist();assert len(names)==len(set(names))
    for n,h in srcmanifest.items():
        assert n in names and hashlib.sha256(z.read(n)).hexdigest()==h,n
        live=root/n
        if not live.is_file():missing.append(n)
        elif hashlib.sha256(live.read_bytes()).hexdigest()!=h:changed.append(n)
    td=root/'BetterScheduler/results/ops/20261025T165514Z/reviewer_followup_package/package_validation/isolated';td.mkdir(parents=True,exist_ok=True);z.extractall(td)
# Verify import resolution from the archived source. Stubs prevent any model/network initialization.
stubs=td.parent/'stubs';stubs.mkdir(exist_ok=True)
(stubs/'transformers.py').write_text('class AutoProcessor:\n @classmethod\n def from_pretrained(cls,*a,**k): raise AssertionError("inference forbidden")\nclass Qwen3VLForConditionalGeneration: pass\n',encoding='utf-8')
(stubs/'ultralytics.py').write_text('class YOLOWorld:\n def __init__(self,*a,**k): raise AssertionError("inference forbidden")\n',encoding='utf-8')
sys.path.insert(0,str(stubs));sys.path.insert(0,str(td))
import BetterScheduler.reviewer_followup as rf
import BetterScheduler.qwen_reviewer as qr
assert Path(rf.__file__).resolve().is_relative_to(td.resolve()) and Path(qr.__file__).resolve().is_relative_to(td.resolve())
assert rf.REVISION=='ebb281ec70b05090aa6165b016eac8ec08e71b17' and rf.PROMPTS==('candidate_provenance_v2','candidate_provenance_explicit_v4')
result={'status':'passed','package_source':'existing staged bundle; no overwrite','private':meta['is_private'],'kernel_id':meta['id'],'accelerator':meta['machine_shape'],'upstream':meta['kernel_sources'][0],'caps':{'server_seconds':1200,'internal_seconds':900,'max_gpu_hours':manifest['maximum_allocated_gpu_hours']},'max_calls':72,'groups_excluded':len(spec['excluded_groups']),'diagnostic_cases':len(spec['diagnostic_cases']),'fresh_control_parents':spec['fresh_control_parents'],'notebook_code_cells':len(code),'embedded_sources':len(embedded),'embedded_zip_matches':True,'manifest_entries':len(srcmanifest),'live_source_mismatches':changed,'live_source_missing':missing,'archive_sha256':zip_sha,'isolated_imports':['BetterScheduler.reviewer_followup','BetterScheduler.qwen_reviewer'],'model_revision':rf.REVISION,'prompt_variants':list(rf.PROMPTS),'model_init_called':False,'launch_command':'kaggle kernels push -p BetterScheduler/staging/20261025g -t 1200 --accelerator NvidiaTeslaT4'}
Path(sys.argv[1]).write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))

