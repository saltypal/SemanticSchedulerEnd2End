import json,hashlib,pathlib,collections
root=pathlib.Path(r'D:\Bunker\BaseCamp\WirelessCommunication\SemanticCommunication\SemanticSchedulerParameterAudit\BetterScheduler\results\cloud_annotation_pilot\20261025e')
run=root/'results/annotation_pilot/20261025e'
checks=json.loads((root/'artifact_checksums.json').read_text())
matched=[];missing=[];bad=[]
for rel,expected in checks.items():
 candidates=[run/rel,root/rel]
 path=next((p for p in candidates if p.is_file()),None)
 if path is None:missing.append(rel);continue
 actual=hashlib.sha256(path.read_bytes()).hexdigest()
 if actual!=expected:bad.append({'path':rel,'expected':expected,'actual':actual})
 else:matched.append(rel)
def rows(rel):return [json.loads(s) for s in (run/rel).read_text(encoding='utf-8').splitlines() if s]
counts={f:len(rows(f)) for f in ['reviews/control_reviews.jsonl','reviews/parameter_reviews.jsonl','parameters/parameters.jsonl','parameters/representations.jsonl','parameters/sequence_trace.jsonl','features/evidence.jsonl','references/references.jsonl']}
controls=rows('reviews/control_reviews.jsonl');params=rows('reviews/parameter_reviews.jsonl')
controlvalid=sum(r.get('status')=='complete' for r in controls)
byview={}
for view in ('compact','structured'):
 group=[r for r in params if r.get('view')==view];valid=[r for r in group if (r.get('review') or {}).get('status')=='complete']
 direct=[r.get('direct_reference_metrics',{}) for r in group]
 byview[view]={'attempts':len(group),'valid_review':len(valid),'consistent_true':sum((r.get('review') or {}).get('parsed',{}).get('parameters_consistent') is True for r in valid),'sufficient_true':sum((r.get('review') or {}).get('parsed',{}).get('representation_sufficient') is True for r in valid),'direct':direct[0] if direct else None}
raw_expected=[k for k in checks if k.startswith('raw/reviewer/')]
raw_dir=run/'raw/reviewer';raw_files=list(raw_dir.glob('*')) if raw_dir.exists() else []
result={'checksum_expected_count':len(checks),'checksum_match_count':len(matched),'checksum_missing_count':len(missing),'checksum_mismatch_count':len(bad),'missing_paths':missing,'mismatches':bad,'expected_raw_review_count':len(raw_expected),'retrieved_raw_review_files':len(raw_files),'retrieved_raw_txt_count':sum(p.suffix=='.txt' for p in raw_files),'jsonl_row_counts':counts,'control_reviews_complete':controlvalid,'parameter_by_view':byview,'executed_notebook_present':(root/'cell_evidence/executed.ipynb').is_file(),'cell_logs_present':len(list((root/'cell_evidence').glob('cell_*.log'))),'cell_status_present':(root/'cell_evidence/cell_status.json').is_file()}
(root.parent/'integrity_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
