"""Evaluator-only reference mapping,controlled cases and binary review contracts."""
from copy import deepcopy
import json
import math
from .contracts import canonical,digest


def native_reference(record):
    """Known facts only. No missing label becomes absence; no blockage/damage alias."""
    native=record.get('native_labels',{});facts={};sources={}
    if record['source']=='ladi':
        mapping={'building.present':'buildings_any','building.affected_or_greater':'buildings_affected_or_greater',
                 'road.present':'roads_any','road.damaged':'roads_damage'}
        for fact,key in mapping.items():
            value=native.get(key)
            if type(value) is bool:facts[fact]=value;sources[fact]=key
    elif record['source']=='medic':
        value=native.get('informative')
        if type(value) is int and value in (0,1):facts['incident.informative']=value==0;sources['incident.informative']='informative ClassLabel0=informative'
        elif value in ('informative','not_informative'):
            facts['incident.informative']=value=='informative';sources['incident.informative']='informative'
    return {'schema':'native_reference_v1','image_id':record['image_id'],'facts':facts,
            'source_fields':sources,'complete_scene_annotation':False,
            'source':record['source'],'group':record['group'],
            'definition':'published native image-level observations; affected_or_greater is not a verified any-visible-damage equivalence; not urgency or full scene truth'}


REQUIRED={'building_damage':('building.present','building.affected_or_greater'),
          'road_damage':('road.present','road.damaged'),
          'road_blockage':('road.present','road.blocked'),
          'household_inventory':('household.target_present',),
          'incident_informativeness':('incident.informative',)}


def make_rubric(mission,reference):
    wanted=REQUIRED[mission.mission_id]
    known=[key for key in wanted if key in reference['facts']]
    return {'rubric_id':digest({'mission':mission.version,'wanted':wanted}),
            'required_fact_names':list(wanted),'reference_supported_facts':known,
            'reference_grading_available':len(known)==len(wanted),
            'rule':'consistent = no contradicted assessed claim; sufficient = consistent and all required facts represented',
            'numerical_checks':'exact cosine,geometry,frequency,clock and calibration are code/reference checks,not visual truth'}


def control_cases(records,missions,parents=24):
    """Three reference-constructed views/image; separate from actual predictions."""
    if type(parents) is not int or parents<2 or parents%2:raise ValueError('balanced controls require an even parent count>=2')
    eligible=sorted((r for r in records if all(k in native_reference(r)['facts']
                  for k in REQUIRED['building_damage'])),key=lambda r:r['image_id'])
    # Balance the corruption target,without using any final groups.
    pools={v:[r for r in eligible if native_reference(r)['facts']['building.affected_or_greater']==v] for v in (False,True)}
    selected=[];seen=set()
    for value,count in ((False,parents//2),(True,parents-parents//2)):
        chosen=0
        for row in pools[value]:
            if row['group'] in seen:continue
            seen.add(row['group']);selected.append(row);chosen+=1
            if chosen==count:break
    if len(selected)<parents:raise ValueError('insufficient independently supported positive/negative control parents')
    cases=[];mission=missions['building_damage']
    for index,row in enumerate(selected):
        ref=native_reference(row);facts={k:ref['facts'][k] for k in REQUIRED['building_damage']}
        for arm in ('complete','incomplete','contradicted'):
            claims=dict(facts)
            if arm=='incomplete':claims.pop('building.affected_or_greater')
            if arm=='contradicted':claims['building.affected_or_greater']=not claims['building.affected_or_greater']
            cases.append({'case_id':f'control-{index}-{arm}','image_id':row['image_id'],
                'image_path':row['image_path'],'reference':ref,'mission_id':mission.mission_id,
                'rubric':make_rubric(mission,ref),'candidate':{'representation':'structured_control',
                'claims':claims,'parameters':{}},'control_arm':arm,'expected':{
                    'parameters_consistent':arm!='contradicted','representation_sufficient':arm=='complete'}})
    return cases


def parse_review(raw):
    """Accept one JSON object,optionally fenced;never coerce strings into booleans."""
    value=raw.strip();recovered=False
    if value.startswith('```'):
        lines=value.splitlines()
        if lines[0] not in ('```json','```') or lines[-1]!='```':raise ValueError('invalid JSON fence')
        value='\n'.join(lines[1:-1]);recovered=True
    def unique(pairs):
        output={}
        for key,item in pairs:
            if key in output:raise ValueError('duplicate review JSON key')
            output[key]=item
        return output
    parsed=json.loads(value,object_pairs_hook=unique)
    required={'parameters_consistent','representation_sufficient','reason','missing_or_conflicting_fields'}
    if not isinstance(parsed,dict) or set(parsed)!=required:raise ValueError('review must use the exact binary schema')
    if any(type(parsed[k]) is not bool for k in ('parameters_consistent','representation_sufficient')):
        raise ValueError('review verdicts must be JSON booleans')
    if not isinstance(parsed['reason'],str) or not parsed['reason'].strip():raise ValueError('review needs an explanation')
    if not isinstance(parsed['missing_or_conflicting_fields'],list) or any(not isinstance(k,str) for k in parsed['missing_or_conflicting_fields']):
        raise ValueError('invalid review discrepancy fields')
    if parsed['representation_sufficient'] and not parsed['parameters_consistent']:
        raise ValueError('sufficiency cannot be true when consistency is false')
    canonical(parsed)
    return parsed,recovered


def reviewer_input(candidate,reference,mission,rubric,history):
    """The user-selected annotation-assisted arm;exclude control arm/answer key."""
    return {'review_mode':'annotation_assisted_visible_json',
        'operator_mission':mission.paragraph,'task_text':dict(mission.conditions),
        'candidate_parameter_representation':deepcopy(candidate),
        'published_annotation_reference':deepcopy(reference),
        'rubric':{k:deepcopy(rubric[k]) for k in ('rubric_id','required_fact_names','rule','numerical_checks')},
        'available_sender_history':deepcopy(history),
        'instructions':[
          'Compare the actual supplied image,partial annotations and candidate JSON under the declared task.',
          'Unknown or unannotated facts are not false. Do not infer injury,urgency,identity or off-image events.',
          'Do not invent a condition omitted from the candidate. A high alignment score alone does not represent a damage fact.',
          'Scores are uncalibrated proxies. Exact numeric correctness is checked by code,not inferred from pixels.',
          'Required fact names have to be explicitly represented or deterministically recoverable from documented candidate fields.',
          'History images are limited to those supplied. Do not certify natural asset identity or global novelty.',
          'Return only JSON with parameters_consistent(boolean),representation_sufficient(boolean),reason(short string),missing_or_conflicting_fields(array of strings).',
          'If consistency is false,sufficiency must be false. Complete scene description and universal importance are not required.']}


def score_controls(cases,outputs):
    case_ids=[c['case_id'] for c in cases];output_ids=[r['case_id'] for r in outputs]
    if len(case_ids)!=len(set(case_ids)) or len(output_ids)!=len(set(output_ids)):
        raise ValueError('duplicate control/output identity')
    if not set(output_ids)<=set(case_ids):raise ValueError('unknown control output identity')
    by_id={r['case_id']:r for r in outputs};metrics={};valid=0
    for case in cases:
        if by_id.get(case['case_id'],{}).get('status')=='complete':valid+=1
    for endpoint in ('parameters_consistent','representation_sufficient'):
        matrix={'tp':0,'tn':0,'fp':0,'fn':0};class_total={False:0,True:0};class_correct={False:0,True:0}
        for case in cases:
            expected=case['expected'][endpoint];class_total[expected]+=1
            row=by_id.get(case['case_id'],{})
            if row.get('status')!='complete':continue # Still in denominator:invalid is not a correct answer.
            predicted=row['parsed'][endpoint]
            matrix[('tp' if predicted else 'fn') if expected else ('fp' if predicted else 'tn')]+=1
            class_correct[expected]+=int(predicted==expected)
        recall={str(k):class_correct[k]/class_total[k] if class_total[k] else None for k in (False,True)}
        metrics[endpoint]={'confusion':matrix,'class_correct_fraction_including_invalid':recall,
                          'balanced_accuracy':sum(recall.values())/2 if all(v is not None for v in recall.values()) else None}
    incomplete=[c for c in cases if c['control_arm']=='incomplete']
    omission=sum(by_id.get(c['case_id'],{}).get('status')=='complete' and
                 not by_id[c['case_id']]['parsed']['representation_sufficient'] for c in incomplete)/len(incomplete) if incomplete else None
    fraction=valid/len(cases) if cases else 0.
    passed=fraction>=.95 and omission is not None and omission>=.75 and all(
        v['balanced_accuracy'] is not None and v['balanced_accuracy']>=.8 and
        min(v['class_correct_fraction_including_invalid'].values())>=.75 for v in metrics.values())
    return {'cases':len(cases),'valid':valid,'valid_fraction':fraction,'endpoints':metrics,
            'omission_rejection_fraction':omission,'engineering_gate_passed':passed,
            'scope':'annotation-assisted audit controls; not independent visual recognition accuracy',
            'images_are_paired_units':True}


def direct_fact_metrics(predictions,reference):
    pairs=[(key,bool(predictions[key]),value) for key,value in reference['facts'].items()
           if key in predictions and type(predictions[key]) is bool]
    return {'known_comparable_facts':len(pairs),'correct':sum(a==b for _,a,b in pairs),
            'accuracy':sum(a==b for _,a,b in pairs)/len(pairs) if pairs else None,
            'missing_reference_facts_in_representation':[k for k in reference['facts'] if k not in predictions],
            'invalid_reference_fact_values':[k for k in reference['facts'] if k in predictions and type(predictions[k]) is not bool],
            'comparisons':[{'fact':k,'prediction':a,'reference':b} for k,a,b in pairs]}
