# Real-cache scheduler component result

{
  "status": "complete",
  "scene_roundtrips": 6000,
  "scene_bytes_mean": 34.45133333333333,
  "scene_bytes_p95": 45,
  "scene_bytes_max": 73,
  "profiles": 1,
  "scene_bytes_scope": "actual encoded scene blocks only; SPI/relevance/novelty/routing/payload and provisioning excluded",
  "channels_retained": 93,
  "field_selection": "not performed; lossless sparse transport retains all channels",
  "training": "not performed; this CPU component run is not the P/neural/RL study",
  "relevance_novelty": "stream-dependent inputs; unavailable in cache; not needed by these four baselines",
  "elapsed_seconds": 11.735557857999993
}

No P/neural/RL training or independent urgency evaluation occurred. Four baseline policies across three dynamic MIXED_IID traces; delays stratified by input SPI only. Temporal missions/relevance/novelty and qualified teacher supervision remain the next components. This notebook did not alter image-cache or SPI production.
